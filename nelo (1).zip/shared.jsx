// Shared building blocks: Sidebar, TopBar, KPI, ConsequenceBox, etc.
const { useState, useEffect, useRef, useMemo } = React;
const { I } = window;

// -------- Hash router (very small) --------
function useRoute() {
  const get = () => (window.location.hash.slice(1) || '/').split('?')[0];
  const getQuery = () => {
    const h = window.location.hash.slice(1);
    const q = h.split('?')[1] || '';
    const params = {};
    new URLSearchParams(q).forEach((v, k) => (params[k] = v));
    return params;
  };
  const [route, setRoute] = useState(get);
  const [query, setQuery] = useState(getQuery);
  useEffect(() => {
    const onHash = () => { setRoute(get()); setQuery(getQuery()); };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  return [route, query, (path) => { window.location.hash = path; }];
}
window.useRoute = useRoute;

// -------- Sidebar --------
const NAV = [
  { to: '/',             label: 'Painel',       icon: I.Home,     dot: true },
  { to: '/producao',     label: 'Produção',     icon: I.Factory,  count: 12 },
  { to: '/planeamento',  label: 'Planeamento',  icon: I.Calendar },
  { to: '/expedicao',    label: 'Expedição',    icon: I.Truck,    count: 4 },
  { to: '/equipa',       label: 'Equipa',       icon: I.Users },
  { to: '/qualidade',    label: 'Qualidade',    icon: I.Shield,   dot: true },
  { to: '/configuracao', label: 'Configuração', icon: I.Settings },
  { to: '/relatorios',   label: 'Relatórios',   icon: I.Chart },
];

function Sidebar({ route, navigate }) {
  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="brand-mark">N</div>
        <div className="brand-name">NELO</div>
        <div className="brand-env">PROD</div>
      </div>
      <div className="sidebar-nav">
        <div className="nav-section-label">Operação</div>
        {NAV.slice(0, 4).map(item => (
          <NavItem key={item.to} {...item} active={item.to === '/' ? route === '/' : route.startsWith(item.to)} onClick={() => navigate(item.to)} />
        ))}
        <div className="nav-section-label">Análise</div>
        {NAV.slice(4, 6).map(item => (
          <NavItem key={item.to} {...item} active={route.startsWith(item.to)} onClick={() => navigate(item.to)} />
        ))}
        <div className="nav-section-label">Sistema</div>
        {NAV.slice(6).map(item => (
          <NavItem key={item.to} {...item} active={route.startsWith(item.to)} onClick={() => navigate(item.to)} />
        ))}
      </div>
      <div className="sidebar-footer">
        <div className="umwelt-switch">
          <button className="umwelt-opt active">GESTOR</button>
          <button className="umwelt-opt">CEO</button>
          <button className="umwelt-opt">OP.</button>
        </div>
        <div className="user-block">
          <div className="user-avatar">JF</div>
          <div className="user-meta">
            <div className="name">— —</div>
            <div className="role">manager_operations</div>
          </div>
        </div>
      </div>
    </aside>
  );
}

function NavItem({ to, label, icon: Icon, active, dot, count, onClick }) {
  return (
    <button className={`nav-item ${active ? 'active' : ''}`} onClick={onClick}>
      <span className="nav-icon"><Icon size={16} /></span>
      {label}
      {count != null && <span className="nav-count">{count}</span>}
      {dot && count == null && <span className="nav-dot" />}
    </button>
  );
}

// -------- TopBar --------
function TopBar({ crumbs, actions }) {
  return (
    <div className="topbar">
      <div className="breadcrumb">
        {crumbs.map((c, i) => (
          <React.Fragment key={i}>
            <span className={i === crumbs.length - 1 ? 'current' : ''}>{c}</span>
            {i < crumbs.length - 1 && <I.ChevronRight size={12} />}
          </React.Fragment>
        ))}
      </div>
      <div className="search-wrap" style={{ marginLeft: 16 }}>
        <I.Search size={14} />
        <input className="search" placeholder="Procurar barco, ordem, peça..." />
        <span className="kbd">⌘K</span>
      </div>
      <div className="topbar-right">
        {actions}
        <button className="icon-btn" title="Notificações">
          <I.Bell size={16} />
          <span className="badge-dot" />
        </button>
        <button className="icon-btn" title="Atalhos"><I.Code size={16} /></button>
        <div className="vdivider" style={{ height: 24, margin: '0 4px' }} />
        <div className="user-avatar" style={{ width: 28, height: 28 }}>JF</div>
      </div>
    </div>
  );
}

// -------- KPI --------
function KPI({ label, value, unit, trend, trendDir = 'up', spark, trust = 'A', accent }) {
  const dir = trendDir === 'flat' ? 'flat' : trendDir;
  return (
    <div className="kpi">
      <div className="kpi-label">
        {label}
        <span className="kpi-trust" title={`Trust ${trust}`}>TRUST·{trust}</span>
      </div>
      <div className="kpi-value">{value}{unit && <span className="unit">{unit}</span>}</div>
      <div className="kpi-trend" style={{ color: dir === 'up' ? 'var(--success)' : dir === 'down' ? 'var(--danger)' : 'var(--fg-2)' }}>
        {dir === 'up' && <I.TrendUp size={11} />}
        {dir === 'down' && <I.TrendDown size={11} />}
        {dir === 'flat' && <I.Minus size={11} />}
        {trend}
      </div>
      {spark && (
        <svg className="kpi-spark" viewBox="0 0 80 32" preserveAspectRatio="none">
          <polyline
            points={spark.map((y, i) => `${(i / (spark.length - 1)) * 80},${32 - y * 32}`).join(' ')}
            fill="none"
            stroke={accent || 'var(--info)'}
            strokeWidth="1.5"
          />
        </svg>
      )}
    </div>
  );
}

// -------- ConsequenceBox --------
function ConsequenceBox({ title = 'Consequência', items }) {
  return (
    <div className="consequence">
      <div className="consequence-title"><I.AlertTriangle size={11} /> {title}</div>
      <ul className="consequence-list">
        {items.map((it, i) => (
          <li key={i}>
            <span className={`delta ${it.kind}`}>{it.delta}</span>
            <span>{it.text}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

// -------- Suggestion (5-box) --------
function SuggestionCard({ icon, title, meta, summary, fields, confidence = 0.84, onAccept, onReject }) {
  const Ic = icon || I.Sparkles;
  return (
    <div className="suggestion">
      <div className="suggestion-head">
        <div className="suggestion-icon"><Ic size={14} /></div>
        <div className="flex-1">
          <div className="suggestion-title">{title}</div>
          <div className="suggestion-meta">{meta}</div>
        </div>
        <span className="badge badge-info">SUGESTÃO</span>
      </div>
      <div className="suggestion-body">
        <div style={{ fontSize: 'var(--t-sm)', color: 'var(--fg-1)' }}>{summary}</div>
      </div>
      <div className="suggestion-grid">
        {fields.map((f, i) => (
          <div key={i}>
            <div className="sg-label">{f.label}</div>
            <div className="sg-value">{f.value}</div>
          </div>
        ))}
      </div>
      <div className="suggestion-foot">
        <div className="confidence">
          <I.Brain size={12} />
          Confiança
          <div className="confidence-bar"><div className="confidence-bar-fill" style={{ width: `${confidence * 100}%` }} /></div>
          <span>{Math.round(confidence * 100)}%</span>
        </div>
        <div className="row gap-2">
          <button className="btn btn-sm btn-ghost" onClick={onReject}>Rejeitar</button>
          <button className="btn btn-sm" onClick={onAccept}>Porquê?</button>
          <button className="btn btn-sm btn-primary" onClick={onAccept}>Aprovar</button>
        </div>
      </div>
    </div>
  );
}

// -------- Tabs --------
function Tabs({ tabs, value, onChange }) {
  return (
    <div className="tabs">
      {tabs.map(t => (
        <button
          key={t.id}
          className={`tab ${value === t.id ? 'active' : ''}`}
          onClick={() => onChange(t.id)}
        >
          {t.label}
          {t.count != null && <span className="tab-count">{t.count}</span>}
        </button>
      ))}
    </div>
  );
}

// -------- Modal --------
function Modal({ title, onClose, children, footer, width = 520 }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose?.();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" style={{ width }} onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3 className="modal-title">{title}</h3>
          <button className="icon-btn" onClick={onClose}><I.X size={14} /></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  );
}

// -------- BoatCard (compact, used in PhaseColumn + Dispatch) --------
function BoatCard({ boat, dragging, onDragStart, onDragEnd, compact = false }) {
  const statusLabel = { on_time: 'EM PRAZO', at_risk: 'EM RISCO', late: 'ATRASO', curing: 'CURA' }[boat.status];
  return (
    <div
      className={`boat-card s-${boat.status} ${dragging ? 'dragging' : ''}`}
      draggable
      onDragStart={(e) => onDragStart?.(e, boat)}
      onDragEnd={onDragEnd}
    >
      <div className="boat-card-row">
        <I.Grip size={12} style={{ color: 'var(--fg-3)' }} />
        <div className="boat-hull">{boat.hull}</div>
        <span className={`badge ${
          boat.status === 'on_time' ? 'badge-success' :
          boat.status === 'at_risk' ? 'badge-warning' :
          boat.status === 'late'    ? 'badge-danger'  : 'badge-info'
        }`} style={{ marginLeft: 'auto' }}>
          {boat.status === 'on_time' && <I.Check size={9} />}
          {boat.status === 'at_risk' && <I.AlertTriangle size={9} />}
          {boat.status === 'late'    && <I.X size={9} />}
          {boat.status === 'curing'  && <I.Clock size={9} />}
          {statusLabel}
        </span>
      </div>
      <div className="boat-client">{boat.client}</div>
      {!compact && (
        <>
          <div className="boat-progress">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className={`seg ${i < boat.phaseIdx ? 'done' : i === boat.phaseIdx ? 'active' : ''}`} />
            ))}
          </div>
          <div className="boat-meta">
            <div className="boat-workers">
              {boat.workers.map((w, i) => (
                <div key={i} className={`boat-worker ${w.warn ? 'warn' : ''}`}>{w.initials}</div>
              ))}
            </div>
            <span>{boat.eta}</span>
          </div>
        </>
      )}
    </div>
  );
}

// -------- Copilot FAB --------
function CopilotFab() {
  return (
    <button className="copilot-fab" title="Copilot">
      <I.Sparkles size={20} />
    </button>
  );
}

Object.assign(window, { Sidebar, TopBar, KPI, ConsequenceBox, SuggestionCard, Tabs, Modal, BoatCard, CopilotFab, NAV });
