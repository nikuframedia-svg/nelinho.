// Tiny inline icon set (Lucide-ish, sized 16 by default).
const Icon = ({ d, size = 16, strokeWidth = 1.7, fill = 'none', children }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor"
       strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    {d ? <path d={d} /> : children}
  </svg>
);

const I = {
  Home: (p) => <Icon {...p}><path d="M3 11l9-8 9 8" /><path d="M5 9v12h14V9" /></Icon>,
  Factory: (p) => <Icon {...p}><path d="M2 20h20" /><path d="M4 20V8l5 3V8l5 3V8l5 3v9" /><path d="M9 14h.01M14 14h.01M19 14h.01" /></Icon>,
  Calendar: (p) => <Icon {...p}><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" /></Icon>,
  Truck: (p) => <Icon {...p}><path d="M1 7h13v10H1zM14 10h4l3 3v4h-7z" /><circle cx="6" cy="18" r="2" /><circle cx="18" cy="18" r="2" /></Icon>,
  Users: (p) => <Icon {...p}><path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" /></Icon>,
  Shield: (p) => <Icon {...p}><path d="M12 2l9 4v6c0 5-4 9-9 10-5-1-9-5-9-10V6l9-4z" /><path d="M9 12l2 2 4-4" /></Icon>,
  Settings: (p) => <Icon {...p}><circle cx="12" cy="12" r="3" /><path d="M19 12a7 7 0 00-.1-1.2l2-1.5-2-3.5-2.4.8a7 7 0 00-2-1.2L14 3h-4l-.5 2.4a7 7 0 00-2 1.2L5 5.8l-2 3.5 2 1.5a7 7 0 000 2.4l-2 1.5 2 3.5 2.4-.8a7 7 0 002 1.2L10 21h4l.5-2.4a7 7 0 002-1.2l2.4.8 2-3.5-2-1.5c.1-.4.1-.8.1-1.2z" /></Icon>,
  Chart: (p) => <Icon {...p}><path d="M3 3v18h18" /><rect x="7" y="12" width="3" height="6" /><rect x="12" y="8" width="3" height="10" /><rect x="17" y="5" width="3" height="13" /></Icon>,
  Search: (p) => <Icon {...p}><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></Icon>,
  Bell: (p) => <Icon {...p}><path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.7 21a2 2 0 01-3.4 0" /></Icon>,
  Sparkles: (p) => <Icon {...p}><path d="M12 3v4M12 17v4M5 12H1M23 12h-4M19 5l-2.8 2.8M7.8 16.2L5 19M19 19l-2.8-2.8M7.8 7.8L5 5" /></Icon>,
  ChevronRight: (p) => <Icon {...p} d="M9 18l6-6-6-6" />,
  ChevronDown: (p) => <Icon {...p} d="M6 9l6 6 6-6" />,
  ArrowRight: (p) => <Icon {...p} d="M5 12h14M13 6l6 6-6 6" />,
  Check: (p) => <Icon {...p} d="M5 12l5 5L20 7" />,
  X: (p) => <Icon {...p} d="M6 6l12 12M18 6L6 18" />,
  Plus: (p) => <Icon {...p} d="M12 5v14M5 12h14" />,
  Minus: (p) => <Icon {...p} d="M5 12h14" />,
  Filter: (p) => <Icon {...p} d="M3 5h18l-7 9v6l-4-2v-4z" />,
  Download: (p) => <Icon {...p}><path d="M12 3v12M7 10l5 5 5-5" /><path d="M3 21h18" /></Icon>,
  Upload: (p) => <Icon {...p}><path d="M12 3v12M7 8l5-5 5 5" /><path d="M3 21h18" /></Icon>,
  Eye: (p) => <Icon {...p}><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z" /><circle cx="12" cy="12" r="3" /></Icon>,
  Zap: (p) => <Icon {...p} d="M13 2L4 13h7l-1 9 9-11h-7z" />,
  AlertCircle: (p) => <Icon {...p}><circle cx="12" cy="12" r="10" /><path d="M12 8v4M12 16h.01" /></Icon>,
  AlertTriangle: (p) => <Icon {...p}><path d="M12 2L2 21h20L12 2z" /><path d="M12 9v5M12 18h.01" /></Icon>,
  CheckCircle: (p) => <Icon {...p}><circle cx="12" cy="12" r="10" /><path d="M8 12l3 3 5-6" /></Icon>,
  Clock: (p) => <Icon {...p}><circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" /></Icon>,
  Activity: (p) => <Icon {...p} d="M22 12h-4l-3 9L9 3l-3 9H2" />,
  Brain: (p) => <Icon {...p}><path d="M9 4a3 3 0 00-3 3v0a3 3 0 00-3 3v0a3 3 0 002 3v0a3 3 0 003 3v0a3 3 0 003 3 3 3 0 003-3v0a3 3 0 003-3v0a3 3 0 002-3v0a3 3 0 00-3-3v0a3 3 0 00-3-3 3 3 0 00-2 1 3 3 0 00-2-1z" /></Icon>,
  Anchor: (p) => <Icon {...p}><circle cx="12" cy="5" r="2" /><path d="M12 7v15M5 14a7 7 0 0014 0M3 14h4M17 14h4" /></Icon>,
  Wrench: (p) => <Icon {...p} d="M14.7 6.3a4 4 0 00-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 005.4-5.4l-3 3-2.4-2.4 3-3z" />,
  Layers: (p) => <Icon {...p}><path d="M12 2L2 7l10 5 10-5z" /><path d="M2 17l10 5 10-5M2 12l10 5 10-5" /></Icon>,
  Database: (p) => <Icon {...p}><ellipse cx="12" cy="5" rx="9" ry="3" /><path d="M3 5v14a9 3 0 0018 0V5M3 12a9 3 0 0018 0" /></Icon>,
  Cpu: (p) => <Icon {...p}><rect x="4" y="4" width="16" height="16" rx="2" /><rect x="9" y="9" width="6" height="6" /><path d="M9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3" /></Icon>,
  FileText: (p) => <Icon {...p}><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" /><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" /></Icon>,
  ShieldAlert: (p) => <Icon {...p}><path d="M12 2l9 4v6c0 5-4 9-9 10-5-1-9-5-9-10V6l9-4z" /><path d="M12 8v4M12 16h.01" /></Icon>,
  Grip: (p) => <Icon {...p}><circle cx="9" cy="6" r="1" fill="currentColor"/><circle cx="9" cy="12" r="1" fill="currentColor"/><circle cx="9" cy="18" r="1" fill="currentColor"/><circle cx="15" cy="6" r="1" fill="currentColor"/><circle cx="15" cy="12" r="1" fill="currentColor"/><circle cx="15" cy="18" r="1" fill="currentColor"/></Icon>,
  TrendUp: (p) => <Icon {...p} d="M3 17l6-6 4 4 8-8M14 7h7v7" />,
  TrendDown: (p) => <Icon {...p} d="M3 7l6 6 4-4 8 8M14 17h7v-7" />,
  Refresh: (p) => <Icon {...p}><path d="M21 12a9 9 0 11-3-6.7L21 8" /><path d="M21 3v5h-5" /></Icon>,
  Play: (p) => <Icon {...p} d="M5 3l14 9-14 9z" fill="currentColor" />,
  Pause: (p) => <Icon {...p}><rect x="6" y="4" width="4" height="16" /><rect x="14" y="4" width="4" height="16" /></Icon>,
  Lock: (p) => <Icon {...p}><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0110 0v4" /></Icon>,
  Code: (p) => <Icon {...p} d="M16 18l6-6-6-6M8 6l-6 6 6 6" />,
  Boat: (p) => <Icon {...p}><path d="M2 21h20l-2-7H4z" /><path d="M12 2v12M3 14V8h18v6M7 8V5h10v3" /></Icon>,
  Mold: (p) => <Icon {...p}><path d="M3 17V8a2 2 0 012-2h2a2 2 0 012 2v9M15 17V8a2 2 0 012-2h2a2 2 0 012 2v9M3 17h18" /></Icon>,
  Print: (p) => <Icon {...p}><path d="M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2" /><rect x="6" y="14" width="12" height="8" /></Icon>,
};

window.I = I;
