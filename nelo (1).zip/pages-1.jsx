// PAGES PART 1: Painel, Produção, Planeamento, Expedição
const { useState: useState1, useEffect: useEffect1, useMemo: useMemo1, useRef: useRef1 } = React;
const { I: Icons1, KPI: KPI1, ConsequenceBox: CB1, SuggestionCard: SC1, Tabs: Tabs1, Modal: Modal1, BoatCard: BC1 } = window;

// ============================================================
// PAINEL
// ============================================================
function PainelPage() {
  return (
    <div className="page" data-screen-label="01 Painel">
      <div className="page-header">
        <div>
          <h1 className="page-title">Painel</h1>
          <p className="page-subtitle">VISÃO GERAL · TURNO DE HOJE · ATUALIZADO HÁ — MIN</p>
        </div>
        <div className="page-actions">
          <button className="btn btn-ghost"><Icons1.Refresh size={14} />Atualizar</button>
          <button className="btn"><Icons1.Filter size={14} />Filtros</button>
          <button className="btn btn-primary"><Icons1.Sparkles size={14} />Pedir ao Copilot</button>
        </div>
      </div>

      <div className="kpi-grid">
        <KPI1 label="€/dia (margem)" value="—" unit="€" trend="vs. semana —%" trendDir="up"
              spark={[0.3, 0.4, 0.35, 0.5, 0.45, 0.6, 0.7]} accent="var(--success)" trust="A" />
        <KPI1 label="Concluídos / plano" value="— /—" trend="aderência —%" trendDir="flat"
              spark={[0.5, 0.6, 0.55, 0.7, 0.65, 0.75, 0.7]} trust="A" />
        <KPI1 label="Em risco" value="—" unit="barcos" trend="—h até crítico" trendDir="down"
              spark={[0.4, 0.5, 0.45, 0.6, 0.55, 0.7, 0.8]} accent="var(--warning)" trust="B" />
        <KPI1 label="Alertas activos" value="—" trend="— novos hoje" trendDir="up"
              spark={[0.2, 0.3, 0.4, 0.3, 0.5, 0.6, 0.7]} accent="var(--danger)" trust="A" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div className="panel">
          <div className="panel-header">
            <div className="panel-title">Alertas activos · 5</div>
            <button className="btn btn-sm btn-ghost">Ver tudo <Icons1.ArrowRight size={12} /></button>
          </div>
          <div className="panel-body flush">
            {[
              { kind: 'danger',  icon: Icons1.AlertCircle,   title: 'Molde —— sem manutenção há —— ciclos', meta: 'PRODUÇÃO · há —min' },
              { kind: 'warning', icon: Icons1.AlertTriangle, title: 'Pintura — tempo de cura excedido em #——',  meta: 'QUALIDADE · há —min' },
              { kind: 'warning', icon: Icons1.Clock,         title: 'Atraso previsto na expedição de ——',       meta: 'EXPEDIÇÃO · há —min' },
              { kind: 'info',    icon: Icons1.Activity,      title: 'OEE da Laminagem caiu —pp na última hora', meta: 'OEE · há —min' },
              { kind: 'info',    icon: Icons1.Database,      title: 'Schema drift detectado em —— (SAP)',       meta: 'DADOS · há —min' },
            ].map((a, i) => (
              <div className="alert-row" key={i}>
                <div className={`alert-icon ${a.kind}`}><a.icon size={14} /></div>
                <div className="flex-1">
                  <div className="alert-title">{a.title}</div>
                  <div className="alert-meta">{a.meta}</div>
                </div>
                <Icons1.ChevronRight size={14} style={{ color: 'var(--fg-3)' }} />
              </div>
            ))}
          </div>
        </div>

        <div className="panel">
          <div className="panel-header">
            <div className="panel-title">Timeline de aprovação · 3 sugestões</div>
            <button className="btn btn-sm btn-ghost">Histórico</button>
          </div>
          <div className="panel-body" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <SC1
              icon={Icons1.Sparkles}
              title="Mover #——— de Lixagem para Pintura"
              meta="CPO · ID SUG-2057"
              summary="Adianta entrega em 1 dia. Liberta cabine 3 da Pintura para #——— que está em risco."
              fields={[
                { label: 'Impacto €', value: '+— €/dia' },
                { label: 'Risco',     value: 'Baixo' },
                { label: 'Prazo',     value: '—— d' },
                { label: 'Recursos',  value: '2 op.' },
                { label: 'Causa',     value: 'gargalo P3' },
              ]}
              confidence={0.86}
            />
            <SC1
              icon={Icons1.Brain}
              title="Sugerir par João·—— para Laminagem"
              meta="WORKFORCE · ID SUG-2058"
              summary="Par com produtividade histórica —% acima da média. Reduz risco de retrabalho em #———."
              fields={[
                { label: 'Produtividade', value: '+—%' },
                { label: 'Skill match',   value: '4/4' },
                { label: 'Fadiga',        value: 'OK' },
                { label: 'Histórico',     value: '— ciclos' },
                { label: 'Risco SPOF',    value: 'Médio' },
              ]}
              confidence={0.78}
            />
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16, marginTop: 16 }}>
        <div className="panel">
          <div className="panel-header">
            <div className="panel-title">Actividade ao vivo</div>
            <span className="pill-status"><span className="dot dot-success" /> AO VIVO · STREAM</span>
          </div>
          <div className="panel-body" style={{ padding: 0 }}>
            {Array.from({ length: 6 }).map((_, i) => (
              <div className="tl-item" key={i} style={{ padding: '12px 16px' }}>
                <div className="tl-time">—:— :—</div>
                <div className="tl-content">
                  <span className="muted mono text-xxs uppercase" style={{ marginRight: 8 }}>OPERAÇÃO</span>
                  <span>Operador <span className="mono">——</span> concluiu fase <span className="mono">PINTURA</span> em <span className="mono">#———</span></span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="panel">
          <div className="panel-header">
            <div className="panel-title">Trust index — fontes de dados</div>
            <span className="badge badge-success">A</span>
          </div>
          <div className="panel-body" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {['SAP MES', 'OPC-UA Linha 1', 'OPC-UA Linha 2', 'Manuais (RFID)', 'Forecast cliente'].map((s, i) => (
              <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ flex: 1, fontSize: 'var(--t-sm)' }}>{s}</div>
                <div className="bar" style={{ width: 80 }}><div className={`bar-fill`} style={{ width: ['96%','89%','82%','71%','64%'][i], background: i < 2 ? 'var(--success)' : i < 4 ? 'var(--warning)' : 'var(--danger)' }} /></div>
                <span className="mono text-xxs muted" style={{ width: 30, textAlign: 'right' }}>{['A','A','B','B','C'][i]}</span>
              </div>
            ))}
            <div className="divider" />
            <div className="text-xs muted">Última ingestão · há — min · — registos · — falhas</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// PRODUÇÃO — PhaseColumnView (peça central)
// ============================================================
const PHASES = [
  { id: 'prep',    name: 'Prep. Molde',  capacity: 4 },
  { id: 'pintura', name: 'Pintura',      capacity: 3, cure: '6h' },
  { id: 'laminag', name: 'Laminagem',    capacity: 6 },
  { id: 'cura',    name: 'Cura',         capacity: 8, cure: '12h' },
  { id: 'cq',      name: 'CQ',           capacity: 2 },
  { id: 'embal',   name: 'Embalagem',    capacity: 3 },
];
const SAMPLE_BOATS = [
  { id: 'b1', hull: 'H-——01', client: 'CLIENTE A · ▮▮▮▮▮▮', phase: 'prep',    phaseIdx: 0, status: 'on_time', workers: [{initials:'J·'},{initials:'M·'}], eta: 'd —— ' },
  { id: 'b2', hull: 'H-——02', client: 'CLIENTE B · ▮▮▮▮▮',  phase: 'prep',    phaseIdx: 0, status: 'at_risk', workers: [{initials:'A·',warn:true}], eta: 'd —— ' },
  { id: 'b3', hull: 'H-——03', client: 'CLIENTE A · ▮▮▮▮▮▮', phase: 'pintura', phaseIdx: 1, status: 'curing',  workers: [{initials:'P·'}], eta: 'cura' },
  { id: 'b4', hull: 'H-——04', client: 'CLIENTE C · ▮▮▮▮',   phase: 'pintura', phaseIdx: 1, status: 'on_time', workers: [{initials:'R·'},{initials:'F·'}], eta: 'd —— ' },
  { id: 'b5', hull: 'H-——05', client: 'CLIENTE B · ▮▮▮▮▮',  phase: 'pintura', phaseIdx: 1, status: 'late',    workers: [{initials:'C·',warn:true}], eta: '—2d' },
  { id: 'b6', hull: 'H-——06', client: 'CLIENTE A · ▮▮▮▮▮▮', phase: 'laminag', phaseIdx: 2, status: 'on_time', workers: [{initials:'J·'},{initials:'M·'},{initials:'L·'}], eta: 'd —— ' },
  { id: 'b7', hull: 'H-——07', client: 'CLIENTE D · ▮▮▮▮▮',  phase: 'laminag', phaseIdx: 2, status: 'at_risk', workers: [{initials:'P·'},{initials:'V·',warn:true}], eta: 'd —— ' },
  { id: 'b8', hull: 'H-——08', client: 'CLIENTE C · ▮▮▮▮',   phase: 'laminag', phaseIdx: 2, status: 'on_time', workers: [{initials:'A·'},{initials:'R·'}], eta: 'd —— ' },
  { id: 'b9', hull: 'H-——09', client: 'CLIENTE A · ▮▮▮▮▮▮', phase: 'cura',    phaseIdx: 3, status: 'curing',  workers: [], eta: '—h restantes' },
  { id: 'b10', hull: 'H-——10', client: 'CLIENTE B · ▮▮▮▮▮', phase: 'cura',    phaseIdx: 3, status: 'curing',  workers: [], eta: '—h restantes' },
  { id: 'b11', hull: 'H-——11', client: 'CLIENTE D · ▮▮▮▮▮', phase: 'cq',      phaseIdx: 4, status: 'on_time', workers: [{initials:'F·'}], eta: 'd —— ' },
  { id: 'b12', hull: 'H-——12', client: 'CLIENTE C · ▮▮▮▮',  phase: 'embal',   phaseIdx: 5, status: 'on_time', workers: [{initials:'L·'},{initials:'M·'}], eta: 'expedição' },
];

function PhaseColumnView({ boats, onMove }) {
  const [dragId, setDragId] = useState1(null);
  const [overPhase, setOverPhase] = useState1(null);
  const [pending, setPending] = useState1(null); // { boat, fromPhase, toPhase }

  const byPhase = useMemo1(() => {
    const m = Object.fromEntries(PHASES.map(p => [p.id, []]));
    boats.forEach(b => m[b.phase]?.push(b));
    return m;
  }, [boats]);

  const handleDragStart = (e, boat) => {
    setDragId(boat.id);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', boat.id);
  };
  const handleDragEnd = () => { setDragId(null); setOverPhase(null); };
  const handleDragOver = (e, phaseId) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setOverPhase(phaseId);
  };
  const handleDrop = (e, phaseId) => {
    e.preventDefault();
    const id = e.dataTransfer.getData('text/plain');
    const boat = boats.find(b => b.id === id);
    if (!boat || boat.phase === phaseId) { handleDragEnd(); return; }
    setPending({ boat, fromPhase: boat.phase, toPhase: phaseId });
    handleDragEnd();
  };

  const confirmMove = () => { onMove(pending.boat.id, pending.toPhase); setPending(null); };

  return (
    <>
      <div className="phase-board">
        {PHASES.map(p => {
          const list = byPhase[p.id] || [];
          const overload = list.length > p.capacity;
          return (
            <div
              key={p.id}
              className={`phase-col ${overPhase === p.id ? 'dropping' : ''} ${overload ? 'overload' : ''}`}
              onDragOver={(e) => handleDragOver(e, p.id)}
              onDragLeave={() => setOverPhase(null)}
              onDrop={(e) => handleDrop(e, p.id)}
            >
              <div className="phase-col-header">
                <div className="phase-col-title">
                  {p.cure ? <Icons1.Clock size={14} style={{color:'var(--info)'}}/> : <Icons1.Layers size={14} style={{color:'var(--fg-2)'}}/>}
                  {p.name}
                  <span className="phase-col-cap">{list.length}/{p.capacity}</span>
                </div>
                <div className={`bar ${overload ? 'danger bar-overload' : list.length / p.capacity > 0.8 ? 'warning' : 'success'}`}>
                  <div className="bar-fill" style={{ width: `${Math.min(100, (list.length / p.capacity) * 100)}%` }} />
                </div>
                <div className="phase-col-meta">
                  {p.cure && <span><Icons1.Clock size={9}/> cura {p.cure}</span>}
                  {overload && <span style={{color:'var(--danger)'}}><Icons1.AlertTriangle size={9}/> sobrecarga</span>}
                  <span style={{marginLeft:'auto'}}>WIP — h</span>
                </div>
              </div>
              <div className="phase-col-list">
                {list.length === 0 && <div className="phase-empty">Sem barcos nesta fase</div>}
                {list.map(b => (
                  <BC1 key={b.id} boat={b} dragging={dragId === b.id} onDragStart={handleDragStart} onDragEnd={handleDragEnd} />
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {pending && (
        <Modal1
          title="Mover barco entre fases"
          onClose={() => setPending(null)}
          footer={<>
            <button className="btn btn-ghost" onClick={() => setPending(null)}>Cancelar</button>
            <button className="btn btn-primary" onClick={confirmMove}><Icons1.Check size={12}/> Confirmar movimento</button>
          </>}
        >
          <div className="kv" style={{ marginBottom: 16 }}>
            <span className="k">Barco</span><span className="mono">{pending.boat.hull}</span>
            <span className="k">Cliente</span><span>{pending.boat.client}</span>
            <span className="k">De</span><span className="mono">{PHASES.find(p=>p.id===pending.fromPhase)?.name}</span>
            <span className="k">Para</span><span className="mono">{PHASES.find(p=>p.id===pending.toPhase)?.name}</span>
          </div>
          <CB1 items={[
            { kind: 'pos', delta: '−1 d',     text: `Adianta entrega prevista de ${pending.boat.hull}.` },
            { kind: 'neg', delta: '+2 h',     text: 'Atrasa #———— por contenção em CQ.' },
            { kind: 'neu', delta: 'cura 6h',  text: 'Tempo mínimo de cura aplicado antes da fase seguinte.' },
            { kind: 'neg', delta: '+— €',     text: 'Custo adicional de setup do molde.' },
          ]} />
          <div style={{ marginTop: 14, padding: 10, background: 'var(--bg-2)', border: '1px solid var(--bd-1)', borderRadius: 4, fontSize: 'var(--t-xs)', color: 'var(--fg-2)', display: 'flex', gap: 8 }}>
            <Icons1.Brain size={14} style={{color:'var(--info)', flexShrink:0, marginTop:1}}/>
            <span>Este movimento desbloqueia a cabine 3 da Pintura, que o CPO sugeriu para #———— (em risco).</span>
          </div>
        </Modal1>
      )}
    </>
  );
}

function ProducaoPage() {
  const [view, setView] = useState1('phases');
  const [boats, setBoats] = useState1(SAMPLE_BOATS);
  const onMove = (id, toPhase) => {
    setBoats(prev => prev.map(b => b.id === id ? { ...b, phase: toPhase, phaseIdx: PHASES.findIndex(p => p.id === toPhase) } : b));
  };
  return (
    <div className="page" data-screen-label="02 Produção">
      <div className="page-header">
        <div>
          <h1 className="page-title">Produção</h1>
          <p className="page-subtitle">MAPA AO VIVO · — BARCOS ACTIVOS · TURNO ——</p>
        </div>
        <div className="page-actions">
          <div className="seg-ctrl">
            <button className={view === 'phases' ? 'active' : ''} onClick={() => setView('phases')}><Icons1.Layers size={12}/>Por fase</button>
            <button className={view === 'gantt' ? 'active' : ''} onClick={() => setView('gantt')}><Icons1.Calendar size={12}/>Gantt</button>
            <button className={view === 'table' ? 'active' : ''} onClick={() => setView('table')}><Icons1.FileText size={12}/>Tabela</button>
          </div>
          <button className="btn"><Icons1.Filter size={14}/>Filtros</button>
          <button className="btn btn-primary"><Icons1.Plus size={14}/>Nova OP</button>
        </div>
      </div>

      <div className="cap-bar-row">
        {PHASES.map(p => {
          const count = boats.filter(b => b.phase === p.id).length;
          const ratio = count / p.capacity;
          const overload = ratio > 1;
          return (
            <div className="cap-cell" key={p.id}>
              <div className="cap-cell-name"><span>{p.name}</span><span className="mono">{count}/{p.capacity}</span></div>
              <div className={`bar ${overload ? 'danger bar-overload' : ratio > 0.8 ? 'warning' : 'success'}`}>
                <div className="bar-fill" style={{ width: `${Math.min(100, ratio * 100)}%` }} />
              </div>
            </div>
          );
        })}
      </div>

      {view === 'phases' && <PhaseColumnView boats={boats} onMove={onMove} />}
      {view === 'gantt' && <GanttView boats={boats} />}
      {view === 'table' && <TableView boats={boats} />}
    </div>
  );
}

function GanttView({ boats }) {
  const days = ['SEG','TER','QUA','QUI','SEX','SÁB','DOM','SEG','TER','QUA','QUI','SEX','SÁB','DOM'];
  return (
    <div className="gantt">
      <div className="gantt-header">
        <div style={{ padding: '10px 12px', fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--fg-2)', letterSpacing: 1, textTransform: 'uppercase' }}>BARCO · CLIENTE</div>
        <div className="gantt-days">
          {days.map((d, i) => (
            <div key={i} className={`gantt-day ${i === 3 ? 'today' : ''} ${i === 5 || i === 6 || i === 12 || i === 13 ? 'weekend' : ''}`}>{d}</div>
          ))}
        </div>
      </div>
      {boats.slice(0, 12).map((b, i) => {
        const start = (i % 7);
        const len = 3 + (i % 4);
        const cls = b.status === 'late' ? 'late' : b.status === 'at_risk' ? 'warn' : b.status === 'curing' ? 'cure' : '';
        return (
          <div className="gantt-row" key={b.id}>
            <div className="gantt-label">
              <div className="mono" style={{fontSize:12, fontWeight:600}}>{b.hull}</div>
              <div className="mono" style={{fontSize:10, color:'var(--fg-2)'}}>{b.client}</div>
            </div>
            <div className="gantt-track" style={{ position:'relative' }}>
              <div className={`gantt-bar ${cls}`} style={{ position:'absolute', left:`${(start/14)*100}%`, width:`${(len/14)*100}%`, top: 0 }}>
                {PHASES[b.phaseIdx]?.name}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function TableView({ boats }) {
  return (
    <div className="panel">
      <table className="tbl">
        <thead>
          <tr>
            <th>Hull</th><th>Cliente</th><th>Fase actual</th><th>Estado</th><th>Operadores</th><th className="num">ETA</th><th className="num">Risco</th><th />
          </tr>
        </thead>
        <tbody>
          {boats.map(b => (
            <tr key={b.id}>
              <td className="mono" style={{fontWeight:600}}>{b.hull}</td>
              <td className="mono">{b.client}</td>
              <td>{PHASES.find(p=>p.id===b.phase)?.name}</td>
              <td>
                <span className={`badge ${
                  b.status==='on_time'?'badge-success':b.status==='at_risk'?'badge-warning':b.status==='late'?'badge-danger':'badge-info'}`}>
                  {b.status==='on_time'?'EM PRAZO':b.status==='at_risk'?'EM RISCO':b.status==='late'?'ATRASO':'CURA'}
                </span>
              </td>
              <td><div className="boat-workers">{b.workers.map((w,i)=>(<div key={i} className={`boat-worker ${w.warn?'warn':''}`}>{w.initials}</div>))}</div></td>
              <td className="mono num">{b.eta}</td>
              <td className="mono num">{['baixo','médio','alto','baixo'][b.phaseIdx % 4]}</td>
              <td><button className="btn btn-sm btn-ghost"><Icons1.ChevronRight size={12}/></button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ============================================================
// PLANEAMENTO
// ============================================================
function PlaneamentoPage() {
  const [tab, setTab] = useState1('atribuicao');
  return (
    <div className="page" data-screen-label="03 Planeamento">
      <div className="page-header">
        <div>
          <h1 className="page-title">Planeamento</h1>
          <p className="page-subtitle">PRÓXIMOS 14 DIAS · WRITE-GATE ACTIVO · APROVADO POR ——</p>
        </div>
        <div className="page-actions">
          <button className="btn"><Icons1.Play size={14}/>Simular</button>
          <button className="btn"><Icons1.Download size={14}/>Exportar</button>
          <button className="btn btn-primary"><Icons1.Lock size={14}/>Aprovar plano</button>
        </div>
      </div>

      <Tabs1 value={tab} onChange={setTab} tabs={[
        { id:'atribuicao', label:'Atribuição' },
        { id:'materiais', label:'Materiais', count: 8 },
        { id:'forecast', label:'Previsão' },
        { id:'simulador', label:'Simulador' },
      ]}/>

      {tab === 'atribuicao' && <AssignmentTab />}
      {tab === 'materiais' && <MateriaisTab />}
      {tab === 'forecast' && <ForecastTab />}
      {tab === 'simulador' && <SimuladorTab />}
    </div>
  );
}

function AssignmentTab() {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'1fr 320px', gap: 16 }}>
      <div className="panel">
        <div className="panel-header">
          <div className="panel-title">Atribuição operador → barco · semana ——</div>
          <div className="row gap-2">
            <span className="badge badge-warning">— pares incompletos</span>
            <span className="badge badge-success">— SPOFs cobertos</span>
          </div>
        </div>
        <div className="panel-body flush">
          <table className="tbl">
            <thead>
              <tr>
                <th>Hull</th><th>Fase próxima</th><th>Skill req.</th><th>Operador 1</th><th>Operador 2</th><th>Match</th><th>Risco</th><th />
              </tr>
            </thead>
            <tbody>
              {SAMPLE_BOATS.slice(0, 9).map((b, i) => (
                <tr key={b.id}>
                  <td className="mono" style={{fontWeight:600}}>{b.hull}</td>
                  <td>{PHASES[(b.phaseIdx + 1) % 6].name}</td>
                  <td><div className="row gap-2">
                    {[1,2,3,4].map(k => <span key={k} className="heat-cell" style={{ width: 14, height: 14, background: k <= 3 ? 'var(--success)' : 'var(--bg-3)' }} />)}
                  </div></td>
                  <td className="mono">OP-{String((i*7)%80).padStart(3,'0')} · ——</td>
                  <td className="mono">{i % 3 === 0 ? <span className="muted">— vago —</span> : `OP-${String((i*13)%80).padStart(3,'0')} · ——`}</td>
                  <td>
                    <div className="bar" style={{ width: 60 }}><div className="bar-fill" style={{ width: `${70 + (i*5)%30}%`, background: i % 4 === 0 ? 'var(--warning)' : 'var(--success)' }} /></div>
                  </td>
                  <td><span className={`badge ${i%4===0?'badge-warning':'badge-success'}`}>{i%4===0?'MÉDIO':'BAIXO'}</span></td>
                  <td><button className="btn btn-sm btn-ghost"><Icons1.Sparkles size={12}/>Sugerir</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="col gap-3">
        <div className="panel">
          <div className="panel-header"><div className="panel-title">Cobertura de skills</div></div>
          <div className="panel-body">
            {['Laminagem','Pintura','CQ','Embalagem','Cura'].map((s, i) => (
              <div key={s} style={{ display:'flex', alignItems:'center', gap:10, marginBottom: 8 }}>
                <div style={{ flex:1, fontSize: 'var(--t-sm)' }}>{s}</div>
                <div className="bar" style={{ width: 100 }}><div className="bar-fill" style={{ width: ['82%','71%','58%','94%','66%'][i], background: i === 2 ? 'var(--danger)' : i === 4 ? 'var(--warning)' : 'var(--success)' }} /></div>
                <span className="mono text-xs muted" style={{ width: 32, textAlign:'right' }}>{['82%','71%','58%','94%','66%'][i]}</span>
              </div>
            ))}
          </div>
        </div>
        <SC1
          icon={Icons1.Brain}
          title="Cobrir CQ com par J·—— + R·——"
          meta="WORKFORCE · ID SUG-2061"
          summary="Atual cobertura 58% (crítico). Par sugerido eleva para 84% e elimina SPOF em CQ."
          fields={[
            { label:'Skill match',  value:'4/4' },
            { label:'Custo extra',  value:'+— €/sem' },
            { label:'Risco SPOF',   value:'Eliminado' },
            { label:'Disp.',        value:'Imediata' },
            { label:'Confiança',    value:'82%' },
          ]}
          confidence={0.82}
        />
      </div>
    </div>
  );
}

function MateriaisTab() {
  return (
    <div className="panel">
      <div className="panel-header">
        <div className="panel-title">MRP · próximos 14 dias</div>
        <div className="row gap-2">
          <span className="badge badge-danger">— em ruptura</span>
          <span className="badge badge-warning">— abaixo ROP</span>
          <button className="btn btn-sm"><Icons1.Plus size={12}/> Encomendar</button>
        </div>
      </div>
      <div className="panel-body flush">
        <table className="tbl">
          <thead><tr><th>SKU</th><th>Material</th><th>Stock</th><th>ROP</th><th>Procura 14d</th><th>Disp.</th><th>Lead time</th><th>Estado</th><th/></tr></thead>
          <tbody>
            {Array.from({length:8}).map((_, i) => (
              <tr key={i}>
                <td className="mono">MAT-{String(1000+i*3).padStart(4,'0')}</td>
                <td>—— · ▮▮▮▮▮▮</td>
                <td className="mono num">— kg</td>
                <td className="mono num">— kg</td>
                <td className="mono num">— kg</td>
                <td><div className="bar" style={{width:80}}><div className="bar-fill" style={{ width: ['92%','45%','12%','67%','83%','29%','58%','75%'][i], background: i===2?'var(--danger)':i===5?'var(--warning)':'var(--success)' }}/></div></td>
                <td className="mono num">— d</td>
                <td><span className={`badge ${i===2?'badge-danger':i===5||i===1?'badge-warning':'badge-success'}`}>{i===2?'RUPTURA':i===5||i===1?'ABAIXO':'OK'}</span></td>
                <td><button className="btn btn-sm btn-ghost"><Icons1.Eye size={12}/></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ForecastTab() {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
      <div className="panel">
        <div className="panel-header"><div className="panel-title">Previsão por cliente · próximos 90 dias</div></div>
        <div className="panel-body">
          <svg width="100%" height="220" viewBox="0 0 600 220">
            <defs><linearGradient id="g1" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="var(--info)" stopOpacity="0.4"/><stop offset="1" stopColor="var(--info)" stopOpacity="0"/></linearGradient></defs>
            {[40,80,120,160,200].map(y => <line key={y} x1="0" y1={y} x2="600" y2={y} stroke="var(--bd-1)" />)}
            <path d="M0,180 L60,160 L120,170 L180,140 L240,150 L300,110 L360,120 L420,90 L480,100 L540,70 L600,80 L600,220 L0,220 Z" fill="url(#g1)" />
            <path d="M0,180 L60,160 L120,170 L180,140 L240,150 L300,110 L360,120 L420,90 L480,100 L540,70 L600,80" fill="none" stroke="var(--info)" strokeWidth="2"/>
            {/* uncertainty band */}
            <path d="M300,110 L360,115 L420,80 L480,90 L540,55 L600,65 L600,95 L540,85 L480,115 L420,100 L360,135 L300,130 Z" fill="var(--info)" opacity="0.1"/>
          </svg>
          <div className="text-xs muted mono">PREVISÃO · ±—% intervalo confiança · modelo —— v—.—</div>
        </div>
      </div>
      <div className="panel">
        <div className="panel-header"><div className="panel-title">Sazonalidade · histórico 24m</div></div>
        <div className="panel-body">
          <div style={{ display:'grid', gridTemplateColumns:'repeat(24, 1fr)', gap:2, marginBottom:12 }}>
            {Array.from({length:24}).map((_,i) => {
              const v = Math.sin(i*0.5) * 0.5 + 0.5;
              return <div key={i} className="heat-cell" style={{ background: `rgba(77,158,246,${v})`, height: 30 }} />;
            })}
          </div>
          <div className="kv">
            <span className="k">Pico</span><span>—— · semana ——</span>
            <span className="k">Vale</span><span>—— · semana ——</span>
            <span className="k">Tendência</span><span>+— %/ano</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function SimuladorTab() {
  return (
    <div className="panel">
      <div className="panel-header"><div className="panel-title">Cenários what-if</div></div>
      <div className="panel-body">
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap: 12 }}>
          {['Cenário A · base','Cenário B · acelerar Pintura','Cenário C · adiar #———'].map((t, i) => (
            <div key={i} className="panel" style={{ background:'var(--bg-2)', padding:14, borderRadius:6 }}>
              <div className="row gap-2" style={{alignItems:'center', marginBottom:8}}>
                <span className="mono text-xxs muted">CENÁRIO</span>
                <span className="badge badge-info">{['ACTIVO','SIMULADO','SIMULADO'][i]}</span>
              </div>
              <div style={{fontSize:'var(--t-md)', fontWeight:600, marginBottom:8}}>{t}</div>
              <div className="kv">
                <span className="k">€/dia</span><span className="mono">{['—','+— €','−— €'][i]}</span>
                <span className="k">Atrasos</span><span className="mono">{['—','—','—'][i]}</span>
                <span className="k">Risco</span><span className="mono">{['BAIXO','MÉDIO','ALTO'][i]}</span>
                <span className="k">Confiança</span><span className="mono">{['—','82%','67%'][i]}</span>
              </div>
              <button className="btn btn-sm" style={{marginTop:10, width:'100%'}}>Comparar</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// EXPEDIÇÃO — 3 rails
// ============================================================
const SHIPMENTS = {
  hoje: [
    { id:'s1', truck:'TRK-——', route:'—— → ——', date:'hoje · —:—', status:'on_time', boats:['H-——12'] },
    { id:'s2', truck:'TRK-——', route:'—— → ——', date:'hoje · —:—', status:'at_risk', boats:['H-——11','H-——09'] },
  ],
  amanha: [
    { id:'s3', truck:'TRK-——', route:'—— → ——', date:'amanhã · —:—', status:'on_time', boats:[] },
    { id:'s4', truck:'TRK-——', route:'—— → ——', date:'amanhã · —:—', status:'on_time', boats:['H-——10'] },
  ],
  semana: [
    { id:'s5', truck:'TRK-——', route:'—— → ——', date:'+ — d', status:'on_time', boats:[] },
    { id:'s6', truck:'TRK-——', route:'—— → ——', date:'+ — d', status:'on_time', boats:[] },
    { id:'s7', truck:'TRK-——', route:'—— → ——', date:'+ — d', status:'at_risk', boats:[] },
  ],
};

function ExpedicaoPage() {
  const [pending, setPending] = useState1(null);
  const [data, setData] = useState1(SHIPMENTS);
  const [overShip, setOverShip] = useState1(null);
  const dragRef = useRef1(null);

  const handleDragStart = (e, hull, fromShip) => {
    dragRef.current = { hull, fromShip };
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', hull);
  };
  const handleDrop = (e, ship) => {
    e.preventDefault();
    setOverShip(null);
    const { hull, fromShip } = dragRef.current || {};
    if (!hull || fromShip === ship.id) return;
    setPending({ hull, from: fromShip, to: ship });
  };
  const confirmMove = () => {
    setData(prev => {
      const next = JSON.parse(JSON.stringify(prev));
      Object.values(next).flat().forEach(s => {
        if (s.id === pending.from) s.boats = s.boats.filter(b => b !== pending.hull);
        if (s.id === pending.to.id) s.boats.push(pending.hull);
      });
      return next;
    });
    setPending(null);
  };

  const Rail = ({ title, count, items, accent }) => (
    <div className="rail">
      <div className="rail-header">
        <div className="rail-title">{title}</div>
        <span className="badge badge-neutral">{count}</span>
        <button className="btn btn-sm btn-ghost" style={{marginLeft:'auto'}}><Icons1.Print size={12}/></button>
      </div>
      <div className="rail-body">
        {items.map(s => (
          <div key={s.id} className={`shipment-card ${overShip === s.id ? 'dropping' : ''}`}
            onDragOver={(e) => { e.preventDefault(); setOverShip(s.id); }}
            onDragLeave={() => setOverShip(null)}
            onDrop={(e) => handleDrop(e, s)}>
            <div className="shipment-head">
              <div className="shipment-truck"><Icons1.Truck size={16}/></div>
              <div className="flex-1">
                <div style={{fontWeight:600, fontSize:'var(--t-sm)'}}>{s.truck}</div>
                <div className="shipment-route">{s.route}</div>
              </div>
              <span className={`badge ${s.status==='on_time'?'badge-success':'badge-warning'}`}>
                {s.status==='on_time'?'EM PRAZO':'EM RISCO'}
              </span>
            </div>
            <div style={{ display:'flex', justifyContent:'space-between', fontFamily:'var(--font-mono)', fontSize:10, color:'var(--fg-2)' }}>
              <span><Icons1.Clock size={9}/> {s.date}</span>
              <span>cap. — / —</span>
            </div>
            <div className="shipment-boats">
              {s.boats.length === 0 && <div className="text-xs muted" style={{textAlign:'center', padding:8}}>arraste barcos para aqui</div>}
              {s.boats.map(h => (
                <div key={h} className="boat-card s-on_time" style={{padding:6}}
                  draggable
                  onDragStart={(e) => handleDragStart(e, h, s.id)}>
                  <div className="boat-card-row">
                    <Icons1.Grip size={11} style={{color:'var(--fg-3)'}}/>
                    <div className="mono" style={{fontWeight:600, fontSize:11}}>{h}</div>
                    <Icons1.Anchor size={11} style={{color:'var(--fg-2)', marginLeft:'auto'}}/>
                  </div>
                </div>
              ))}
            </div>
            <div className="row gap-2">
              <button className="btn btn-sm btn-ghost"><Icons1.Sparkles size={11}/>Porquê?</button>
              <button className="btn btn-sm btn-ghost" style={{marginLeft:'auto'}}><Icons1.Eye size={11}/>Detalhe</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="page" data-screen-label="04 Expedição" style={{ display:'flex', flexDirection:'column' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Expedição</h1>
          <p className="page-subtitle">— CAMIÕES PROGRAMADOS · — BARCOS PARA ENVIAR · CAPACIDADE — %</p>
        </div>
        <div className="page-actions">
          <button className="btn"><Icons1.Calendar size={14}/>Calendário</button>
          <button className="btn"><Icons1.Print size={14}/>Imprimir guias</button>
          <button className="btn btn-primary"><Icons1.Plus size={14}/>Nova expedição</button>
        </div>
      </div>

      <SC1
        icon={Icons1.Sparkles}
        title="Combinar TRK-—— e TRK-—— para —— → ——"
        meta="DESPACHO · ID SUG-2074"
        summary="Mesma rota e janela. Reduz custo logístico em — €. Ambos têm capacidade folga."
        fields={[
          { label:'Poupança',  value:'— €' },
          { label:'Capacidade', value:'— / — m³' },
          { label:'Janela',    value:'—— h' },
          { label:'Risco',     value:'BAIXO' },
          { label:'Cliente',   value:'mesmo' },
        ]}
        confidence={0.91}
      />

      <div className="dispatch-grid" style={{ marginTop: 16 }}>
        <Rail title="HOJE" count={data.hoje.length} items={data.hoje} />
        <Rail title="AMANHÃ" count={data.amanha.length} items={data.amanha} />
        <Rail title="ESTA SEMANA" count={data.semana.length} items={data.semana} />
      </div>

      {pending && (
        <Modal1
          title="Mover barco entre expedições"
          onClose={() => setPending(null)}
          footer={<>
            <button className="btn btn-ghost" onClick={() => setPending(null)}>Cancelar</button>
            <button className="btn btn-primary" onClick={confirmMove}><Icons1.Check size={12}/> Confirmar</button>
          </>}
        >
          <div className="kv" style={{ marginBottom: 14 }}>
            <span className="k">Barco</span><span className="mono">{pending.hull}</span>
            <span className="k">Para</span><span className="mono">{pending.to.truck} · {pending.to.date}</span>
          </div>
          <CB1 items={[
            { kind:'pos', delta:'−1 d',  text:'Adianta entrega ao cliente.' },
            { kind:'neg', delta:'+— €', text:'Custo extra de carregamento.' },
            { kind:'neu', delta:'cap.', text:'Camião ficará a — % da capacidade.' },
          ]} />
        </Modal1>
      )}
    </div>
  );
}

window.PainelPage = PainelPage;
window.ProducaoPage = ProducaoPage;
window.PlaneamentoPage = PlaneamentoPage;
window.ExpedicaoPage = ExpedicaoPage;
