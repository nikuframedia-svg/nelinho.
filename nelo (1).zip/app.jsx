// App shell — composes Sidebar + TopBar + page router
const { useState: useStateApp } = React;

function App() {
  const [route, query, navigate] = window.useRoute();

  let Page = window.PainelPage;
  let crumbs = ['Nelo', 'Painel'];
  if (route === '/producao')        { Page = window.ProducaoPage;     crumbs = ['Nelo', 'Operação', 'Produção']; }
  else if (route === '/planeamento'){ Page = window.PlaneamentoPage;  crumbs = ['Nelo', 'Operação', 'Planeamento']; }
  else if (route === '/expedicao')  { Page = window.ExpedicaoPage;    crumbs = ['Nelo', 'Operação', 'Expedição']; }
  else if (route === '/equipa')     { Page = window.EquipaPage;       crumbs = ['Nelo', 'Análise', 'Equipa']; }
  else if (route === '/qualidade')  { Page = window.QualidadePage;    crumbs = ['Nelo', 'Análise', 'Qualidade']; }
  else if (route === '/configuracao'){ Page = window.ConfiguracaoPage; crumbs = ['Nelo', 'Sistema', 'Configuração']; }
  else if (route === '/relatorios') { Page = window.RelatoriosPage;   crumbs = ['Nelo', 'Sistema', 'Relatórios']; }

  return (
    <div className="app">
      <window.Sidebar route={route} navigate={navigate} />
      <div className="main">
        <window.TopBar crumbs={crumbs} />
        <Page query={query} />
      </div>
      <window.CopilotFab />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
