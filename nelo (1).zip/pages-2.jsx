// PAGES PART 2: Equipa, Qualidade, Configuração, Relatórios
const { useState: useState2, useMemo: useMemo2 } = React;
const { I: Icons2, KPI: KPI2, Tabs: Tabs2 } = window;

// ============================================================
// EQUIPA
// ============================================================
function EquipaPage() {
  const [tab, setTab] = useState2('lista');
  return (
    <div className="page" data-screen-label="05 Equipa">
      <div className="page-header">
        <div>
          <h1 className="page-title">Equipa</h1>
          <p className="page-subtitle">— COLABORADORES · — TURNOS · — SPOFs CRÍTICOS</p>
        </div>
        <div className="page-actions">
          <button className="btn"><Icons2.Download size={14}/>Exportar</button>
          <button className="btn btn-primary"><Icons2.Plus size={14}/>Novo colaborador</button>
        </div>
      </div>
      <Tabs2 value={tab} onChange={setTab} tabs={[
        { id:'lista',         label:'Lista',         count: 80 },
        { id:'alocacoes',     label:'Alocações' },
        { id:'produtividade', label:'Produtividade' },
        { id:'risco',         label:'Risco',         count: 3 },
        { id:'simulador',     label:'Simulador' },
        { id:'formacao',      label:'Formação' },
      ]}/>
      {tab==='lista' && <EmpListaTab/>}
      {tab==='alocacoes' && <AlocacoesTab/>}
      {tab==='produtividade' && <ProdutividadeTab/>}
      {tab==='risco' && <RiscoTab/>}
      {tab==='simulador' && <SimEquipaTab/>}
      {tab==='formacao' && <FormacaoTab/>}
    </div>
  );
}

function EmpListaTab() {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'320px 1fr', gap:16 }}>
      <div className="panel">
        <div className="panel-header">
          <div className="panel-title">Filtros</div>
        </div>
        <div className="panel-body" style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {['Departamento','Skill principal','Turno','Senioridade','Disponibilidade'].map(f => (
            <div key={f}>
              <div className="text-xxs muted mono uppercase" style={{marginBottom:4}}>{f}</div>
              <div style={{ background:'var(--bg-2)', border:'1px solid var(--bd-1)', borderRadius:4, padding:'6px 10px', display:'flex', justifyContent:'space-between', fontSize:12 }}>
                <span className="muted">Todos</span><Icons2.ChevronDown size={12}/>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="panel">
        <div className="panel-header"><div className="panel-title">Colaboradores · 80</div>
          <div className="search-wrap"><Icons2.Search size={12}/><input className="search" style={{width:200}} placeholder="Procurar..."/></div>
        </div>
        <div className="panel-body flush">
          <table className="tbl">
            <thead><tr><th>ID</th><th>Nome</th><th>Departamento</th><th>Skills</th><th>Disp.</th><th>Produtividade</th><th>SPOF</th><th/></tr></thead>
            <tbody>
              {Array.from({length:10}).map((_,i)=>(
                <tr key={i}>
                  <td className="mono">OP-{String(100+i*3).padStart(3,'0')}</td>
                  <td>—— ——</td>
                  <td className="mono text-xs">{['Laminagem','Pintura','CQ','Embalagem','Cura'][i%5]}</td>
                  <td><div className="row gap-2">{[1,2,3,4].map(k=><span key={k} className="heat-cell" style={{ width:12, height:12, background: k <= ((i%4)+1) ? 'var(--success)' : 'var(--bg-3)' }}/>)}</div></td>
                  <td><span className={`pill-status`}><span className={`dot ${['dot-success','dot-warning','dot-success','dot-success','dot-neutral'][i%5]}`}/>{['ON','FÉRIAS','ON','ON','OFF'][i%5]}</span></td>
                  <td><div className="bar" style={{width:80}}><div className="bar-fill" style={{ width:`${60+(i*7)%40}%` }}/></div></td>
                  <td>{i%4===0?<span className="badge badge-warning">SPOF</span>:<span className="muted text-xs">—</span>}</td>
                  <td><button className="btn btn-sm btn-ghost"><Icons2.ChevronRight size={12}/></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function AlocacoesTab() {
  const days = ['SEG','TER','QUA','QUI','SEX','SÁB','DOM'];
  return (
    <div className="panel">
      <div className="panel-header">
        <div className="panel-title">Alocações · semana ——</div>
        <div className="row gap-2"><span className="badge badge-warning">— sobrecargas</span><span className="badge badge-success">cobertura — %</span></div>
      </div>
      <div className="panel-body flush">
        <div style={{ display:'grid', gridTemplateColumns:'180px repeat(7, 1fr)', borderBottom:'1px solid var(--bd-1)', background:'var(--bg-2)' }}>
          <div style={{padding:'8px 12px', fontFamily:'var(--font-mono)', fontSize:10, color:'var(--fg-2)', letterSpacing:1, textTransform:'uppercase'}}>OPERADOR</div>
          {days.map(d => <div key={d} style={{padding:'8px', textAlign:'center', fontFamily:'var(--font-mono)', fontSize:10, color:'var(--fg-2)', borderLeft:'1px solid var(--bd-1)'}}>{d}</div>)}
        </div>
        {Array.from({length:8}).map((_,i)=>(
          <div key={i} style={{ display:'grid', gridTemplateColumns:'180px repeat(7, 1fr)', borderBottom:'1px solid var(--bd-1)' }}>
            <div style={{padding:'10px 12px'}} className="mono text-xs">OP-{String(100+i*3).padStart(3,'0')} · ——</div>
            {days.map((d, j) => {
              const intensity = (i*3 + j) % 5;
              const colors = ['var(--bg-2)', 'rgba(63,185,80,0.2)', 'rgba(63,185,80,0.5)', 'var(--success)', 'var(--danger)'];
              return (
                <div key={d} style={{ padding:4, borderLeft:'1px solid var(--bd-1)' }}>
                  <div style={{ background:colors[intensity], height:36, borderRadius:3, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'var(--font-mono)', fontSize:10, color: intensity > 1 ? '#0c1015' : 'var(--fg-2)' }}>
                    {intensity===0?'—':intensity===4?'—h':'#H-——'}
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

function ProdutividadeTab() {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
      <div className="panel">
        <div className="panel-header"><div className="panel-title">Top 10 pares · produtividade</div></div>
        <div className="panel-body flush">
          <table className="tbl">
            <thead><tr><th>#</th><th>Par</th><th>Operações</th><th className="num">Eficiência</th><th>Tendência</th></tr></thead>
            <tbody>
              {Array.from({length:8}).map((_,i)=>(
                <tr key={i}>
                  <td className="mono">{i+1}</td>
                  <td className="mono text-xs">OP-{String(100+i).padStart(3,'0')} · OP-{String(150+i).padStart(3,'0')}</td>
                  <td className="mono num">—</td>
                  <td className="num"><div className="bar" style={{width:80, marginLeft:'auto'}}><div className="bar-fill" style={{ width:`${90-i*5}%`, background:'var(--success)' }}/></div></td>
                  <td><Icons2.TrendUp size={12} style={{color:'var(--success)'}}/></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="panel">
        <div className="panel-header"><div className="panel-title">Produtividade vs. fadiga</div></div>
        <div className="panel-body">
          <svg width="100%" height="240" viewBox="0 0 400 240">
            {[0,1,2,3,4].map(i => <line key={i} x1="40" y1={20+i*45} x2="400" y2={20+i*45} stroke="var(--bd-1)" />)}
            {[0,1,2,3,4,5].map(i => <line key={i} x1={40+i*60} y1="20" x2={40+i*60} y2="220" stroke="var(--bd-1)" />)}
            {Array.from({length:30}).map((_,i)=>{
              const x = 50 + (i*11) % 340;
              const y = 30 + (Math.sin(i*0.5)*40 + 80) % 170;
              const c = y > 130 ? 'var(--danger)' : y > 90 ? 'var(--warning)' : 'var(--success)';
              return <circle key={i} cx={x} cy={y} r="4" fill={c} opacity="0.7"/>;
            })}
            <text x="220" y="235" fontSize="9" fill="var(--fg-2)" fontFamily="var(--font-mono)" textAnchor="middle">FADIGA →</text>
            <text x="20" y="120" fontSize="9" fill="var(--fg-2)" fontFamily="var(--font-mono)" textAnchor="middle" transform="rotate(-90, 20, 120)">PRODUTIVIDADE →</text>
          </svg>
        </div>
      </div>
    </div>
  );
}

function RiscoTab() {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr', gap:16 }}>
      <div className="panel">
        <div className="panel-header"><div className="panel-title">Mapa de risco · skill × cobertura</div></div>
        <div className="panel-body">
          <div style={{ display:'grid', gridTemplateColumns:'120px repeat(8, 1fr)', gap:2, fontFamily:'var(--font-mono)', fontSize:10 }}>
            <div></div>
            {Array.from({length:8}).map((_,i)=><div key={i} style={{textAlign:'center', color:'var(--fg-2)', padding:'4px 0'}}>OP-{String(i*10+100).padStart(3,'0')}</div>)}
            {['Laminagem','Pintura','CQ','Embalagem','Cura','Acabamento','Soldadura','Eléctrica'].map((s, row) => (
              <React.Fragment key={s}>
                <div style={{ padding:6, color:'var(--fg-1)' }}>{s}</div>
                {Array.from({length:8}).map((_,col)=>{
                  const v = (row*7 + col*3) % 5;
                  const colors = ['var(--bg-2)', 'rgba(248,81,73,0.5)', 'rgba(210,153,34,0.5)', 'rgba(63,185,80,0.5)', 'var(--success)'];
                  return <div key={col} style={{ background: colors[v], height: 28, borderRadius:2, display:'flex', alignItems:'center', justifyContent:'center', color: v>2?'#0c1015':'var(--fg-3)' }}>{v===0?'—':v}</div>;
                })}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
      <div className="panel">
        <div className="panel-header"><div className="panel-title">SPOFs detectados</div><span className="badge badge-danger">3</span></div>
        <div className="panel-body" style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {[
            { skill:'Soldadura especializada', op:'OP-——', cover:'1/80', risk:'CRÍTICO' },
            { skill:'Laminagem high-spec',     op:'OP-——', cover:'2/80', risk:'ALTO' },
            { skill:'CQ visual avançado',      op:'OP-——', cover:'2/80', risk:'ALTO' },
          ].map((r,i)=>(
            <div key={i} style={{ padding:12, background:'var(--bg-2)', border:'1px solid var(--bd-2)', borderLeft:`3px solid ${i===0?'var(--danger)':'var(--warning)'}`, borderRadius:4 }}>
              <div className="row gap-2" style={{alignItems:'center', marginBottom:6}}>
                <Icons2.ShieldAlert size={14} style={{color:i===0?'var(--danger)':'var(--warning)'}}/>
                <div style={{fontWeight:600, fontSize:'var(--t-sm)'}}>{r.skill}</div>
                <span className={`badge ${i===0?'badge-danger':'badge-warning'}`} style={{marginLeft:'auto'}}>{r.risk}</span>
              </div>
              <div className="kv">
                <span className="k">Cobertura</span><span className="mono">{r.cover}</span>
                <span className="k">Sugestão</span><span>Formar — colaboradores</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function SimEquipaTab() {
  return (
    <div className="panel">
      <div className="panel-header"><div className="panel-title">Simulador what-if · ausência</div></div>
      <div className="panel-body">
        <div style={{ display:'grid', gridTemplateColumns:'320px 1fr', gap: 24 }}>
          <div className="col gap-3">
            <div>
              <div className="text-xxs muted mono uppercase" style={{marginBottom:6}}>Operador a remover</div>
              <div style={{ background:'var(--bg-2)', border:'1px solid var(--bd-1)', borderRadius:4, padding:'8px 12px', display:'flex', justifyContent:'space-between' }}>
                <span className="mono">OP-—— · ——</span><Icons2.ChevronDown size={12}/>
              </div>
            </div>
            <div>
              <div className="text-xxs muted mono uppercase" style={{marginBottom:6}}>Período</div>
              <div style={{ background:'var(--bg-2)', border:'1px solid var(--bd-1)', borderRadius:4, padding:'8px 12px', display:'flex', justifyContent:'space-between' }}>
                <span className="mono">— a — d</span><Icons2.ChevronDown size={12}/>
              </div>
            </div>
            <button className="btn btn-primary" style={{justifyContent:'center'}}><Icons2.Play size={12}/>Simular impacto</button>
          </div>
          <div className="col gap-3">
            <div className="text-xxs muted mono uppercase">CASCATA DE IMPACTO</div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8 }}>
              {['Barcos afectados','Atraso médio','Custo extra','Cobertura cai'].map((m,i)=>(
                <div key={m} style={{ background:'var(--bg-2)', border:'1px solid var(--bd-1)', borderRadius:4, padding:12 }}>
                  <div className="text-xxs muted mono uppercase">{m}</div>
                  <div style={{ fontSize:'var(--t-xl)', fontWeight:600, marginTop:4 }}>—{['','d','€','pp'][i] && <span className="muted text-sm" style={{marginLeft:4}}>{['barcos','d','€','pp'][i]}</span>}</div>
                </div>
              ))}
            </div>
            <div className="text-xxs muted mono uppercase">DEPENDÊNCIAS</div>
            <svg width="100%" height="160" viewBox="0 0 600 160">
              <line x1="80" y1="80" x2="220" y2="40" stroke="var(--warning)" strokeWidth="1.5"/>
              <line x1="80" y1="80" x2="220" y2="80" stroke="var(--warning)" strokeWidth="1.5"/>
              <line x1="80" y1="80" x2="220" y2="120" stroke="var(--warning)" strokeWidth="1.5"/>
              <line x1="220" y1="40" x2="380" y2="40" stroke="var(--bd-2)" strokeWidth="1"/>
              <line x1="220" y1="120" x2="380" y2="120" stroke="var(--bd-2)" strokeWidth="1"/>
              <circle cx="80" cy="80" r="22" fill="var(--danger-soft)" stroke="var(--danger)" strokeWidth="2"/>
              <text x="80" y="84" fontSize="10" fill="var(--danger)" textAnchor="middle" fontFamily="var(--font-mono)">OP-——</text>
              {[40,80,120].map((y,i)=>(<g key={i}><circle cx="220" cy={y} r="16" fill="var(--bg-2)" stroke="var(--warning)"/><text x="220" y={y+3} fontSize="9" fill="var(--fg-1)" textAnchor="middle" fontFamily="var(--font-mono)">H-——</text></g>))}
              {[40,120].map((y,i)=>(<g key={i}><circle cx="380" cy={y} r="14" fill="var(--bg-2)" stroke="var(--bd-2)"/><text x="380" y={y+3} fontSize="9" fill="var(--fg-2)" textAnchor="middle" fontFamily="var(--font-mono)">H-——</text></g>))}
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function FormacaoTab() {
  return (
    <div className="panel">
      <div className="panel-header"><div className="panel-title">Plano de formação sugerido</div></div>
      <div className="panel-body">
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12 }}>
          {Array.from({length:6}).map((_,i)=>(
            <div key={i} style={{ padding:14, background:'var(--bg-2)', border:'1px solid var(--bd-1)', borderRadius:6 }}>
              <div className="row gap-2" style={{ marginBottom:8 }}>
                <Icons2.Brain size={14} style={{color:'var(--info)'}}/>
                <div className="mono text-xxs uppercase muted">FORMAÇÃO #{i+1}</div>
                <span className={`badge ${['badge-danger','badge-warning','badge-info'][i%3]}`} style={{marginLeft:'auto'}}>{['ALTA','MÉDIA','BAIXA'][i%3]}</span>
              </div>
              <div style={{ fontWeight:600, marginBottom:8 }}>—— em {['Laminagem','Pintura','CQ','Soldadura','Embalagem','Cura'][i]}</div>
              <div className="kv text-xs">
                <span className="k">Operadores</span><span>—</span>
                <span className="k">Duração</span><span>— h</span>
                <span className="k">Custo</span><span>— €</span>
                <span className="k">ROI</span><span>+— € / mês</span>
              </div>
              <button className="btn btn-sm" style={{marginTop:10, width:'100%'}}>Programar</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// QUALIDADE
// ============================================================
function QualidadePage() {
  const [tab, setTab] = useState2('resumo');
  return (
    <div className="page" data-screen-label="06 Qualidade">
      <div className="page-header">
        <div>
          <h1 className="page-title">Qualidade</h1>
          <p className="page-subtitle">— DEFEITOS ABERTOS · — RETRABALHOS · OEE — %</p>
        </div>
        <div className="page-actions">
          <button className="btn"><Icons2.Filter size={14}/>Filtros</button>
          <button className="btn btn-primary"><Icons2.Plus size={14}/>Registar defeito</button>
        </div>
      </div>
      <Tabs2 value={tab} onChange={setTab} tabs={[
        { id:'resumo',     label:'Resumo' },
        { id:'erros',      label:'Erros',      count: 12 },
        { id:'moldes',     label:'Moldes' },
        { id:'retrabalho', label:'Retrabalho', count: 5 },
        { id:'diagnostico',label:'Diagnóstico' },
        { id:'oee',        label:'OEE' },
      ]}/>
      {tab==='resumo' && <QualResumoTab/>}
      {tab==='erros' && <QualErrosTab/>}
      {tab==='moldes' && <QualMoldesTab/>}
      {tab==='retrabalho' && <QualRetrabTab/>}
      {tab==='diagnostico' && <QualDiagTab/>}
      {tab==='oee' && <QualOEETab/>}
    </div>
  );
}

function QualResumoTab() {
  return (
    <>
      <div className="kpi-grid">
        <KPI2 label="First-pass yield" value="—" unit="%" trend="—pp vs. semana" trendDir="up" trust="A" spark={[0.5,0.6,0.55,0.65,0.7,0.68,0.72]}/>
        <KPI2 label="Defeitos / barco" value="—" trend="—% vs. mês" trendDir="down" trust="A" accent="var(--success)" spark={[0.7,0.6,0.55,0.5,0.45,0.4,0.35]}/>
        <KPI2 label="MTTR" value="—" unit="h" trend="—h vs. baseline" trendDir="flat" trust="B" spark={[0.5,0.5,0.5,0.5,0.5,0.5,0.5]}/>
        <KPI2 label="Custo retrabalho" value="—" unit="€" trend="—%" trendDir="down" accent="var(--success)" trust="A" spark={[0.6,0.55,0.5,0.45,0.4,0.35,0.3]}/>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
        <div className="panel">
          <div className="panel-header"><div className="panel-title">Pareto · causas raiz</div></div>
          <div className="panel-body">
            <svg width="100%" height="260" viewBox="0 0 600 260">
              {Array.from({length:8}).map((_,i)=>{
                const h = 200 - i*22;
                return <rect key={i} x={20+i*70} y={220-h} width="50" height={h} fill="var(--info)" opacity={0.9 - i*0.08}/>;
              })}
              <polyline points="45,40 115,80 185,120 255,150 325,170 395,185 465,195 535,200" fill="none" stroke="var(--accent)" strokeWidth="2"/>
              {Array.from({length:8}).map((_,i)=>(<text key={i} x={45+i*70} y={235} fontSize="9" fill="var(--fg-2)" textAnchor="middle" fontFamily="var(--font-mono)">C{i+1}</text>))}
            </svg>
          </div>
        </div>
        <div className="panel">
          <div className="panel-header"><div className="panel-title">Defeitos por fase</div></div>
          <div className="panel-body">
            {['Prep. Molde','Pintura','Laminagem','Cura','CQ','Embalagem'].map((p,i)=>(
              <div key={p} style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8 }}>
                <div style={{ flex:1, fontSize:'var(--t-sm)' }}>{p}</div>
                <div className="bar" style={{ width:200 }}><div className="bar-fill" style={{ width:`${[40,75,30,50,85,15][i]}%`, background: i===4?'var(--danger)':i===1?'var(--warning)':'var(--info)' }}/></div>
                <span className="mono text-xs" style={{ width:32, textAlign:'right', color:'var(--fg-1)' }}>—</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

function QualErrosTab() {
  return (
    <div className="panel">
      <div className="panel-body flush">
        <table className="tbl">
          <thead><tr><th>ID</th><th>Hull</th><th>Fase</th><th>Tipo</th><th>Severidade</th><th>Operador</th><th>Aberto há</th><th>Estado</th><th/></tr></thead>
          <tbody>
            {Array.from({length:10}).map((_,i)=>(
              <tr key={i}>
                <td className="mono">DEF-{String(2000+i).padStart(4,'0')}</td>
                <td className="mono">H-——{(10+i).toString().padStart(2,'0')}</td>
                <td>{['Pintura','CQ','Laminagem','Cura','Pintura'][i%5]}</td>
                <td className="text-xs">{['Risco superfície','Bolha','Espessura','Cor','Selagem'][i%5]} · ▮▮▮▮</td>
                <td><span className={`badge ${['badge-danger','badge-warning','badge-warning','badge-success'][i%4]}`}>{['CRÍTICO','MAIOR','MAIOR','MENOR'][i%4]}</span></td>
                <td className="mono text-xs">OP-——</td>
                <td className="mono num">— h</td>
                <td><span className={`badge ${i%3===0?'badge-info':'badge-warning'}`}>{i%3===0?'EM REVISÃO':'EM CURSO'}</span></td>
                <td><button className="btn btn-sm btn-ghost"><Icons2.Eye size={12}/></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function QualMoldesTab() {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12 }}>
      {Array.from({length:8}).map((_,i)=>{
        const cycles = (i*47) % 100;
        const state = cycles > 80 ? 'CRÍTICO' : cycles > 60 ? 'ATENÇÃO' : 'OK';
        return (
          <div key={i} className="panel" style={{ padding:14 }}>
            <div className="row gap-2" style={{alignItems:'center', marginBottom:10}}>
              <Icons2.Mold size={16} style={{color:'var(--fg-2)'}}/>
              <div className="mono" style={{fontWeight:600}}>MOLDE-{String(i+1).padStart(2,'0')}</div>
              <span className={`badge ${cycles>80?'badge-danger':cycles>60?'badge-warning':'badge-success'}`} style={{marginLeft:'auto'}}>{state}</span>
            </div>
            <div className="kv text-xs" style={{marginBottom:10}}>
              <span className="k">Ciclos</span><span className="mono">{cycles}/100</span>
              <span className="k">Próx. man.</span><span className="mono">{100-cycles} ciclos</span>
              <span className="k">Defeitos</span><span className="mono">{Math.floor(cycles/15)}</span>
            </div>
            <div className={`bar ${cycles>80?'danger':cycles>60?'warning':'success'}`}><div className="bar-fill" style={{ width:`${cycles}%` }}/></div>
          </div>
        );
      })}
    </div>
  );
}

function QualRetrabTab() {
  return (
    <div className="panel">
      <div className="panel-header"><div className="panel-title">Retrabalhos abertos · 5</div></div>
      <div className="panel-body flush">
        <table className="tbl">
          <thead><tr><th>Hull</th><th>Defeito</th><th>Custo estimado</th><th>Tempo extra</th><th>Atribuído</th><th>Estado</th><th/></tr></thead>
          <tbody>
            {Array.from({length:5}).map((_,i)=>(
              <tr key={i}>
                <td className="mono">H-——{(20+i*3).toString().padStart(2,'0')}</td>
                <td>{['Selagem','Pintura','Espessura','Bolha','Risco'][i]} · ▮▮▮▮</td>
                <td className="mono num">— €</td>
                <td className="mono num">— h</td>
                <td className="mono text-xs">OP-—— + OP-——</td>
                <td><span className={`badge ${i===0?'badge-danger':'badge-warning'}`}>{i===0?'CRÍTICO':'EM CURSO'}</span></td>
                <td><button className="btn btn-sm btn-ghost"><Icons2.ChevronRight size={12}/></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function QualDiagTab() {
  return (
    <div className="col gap-3">
      <div className="panel">
        <div className="panel-header"><div className="panel-title">Diagnóstico automático · DEF-2003</div><span className="badge badge-info">EXPLAIN</span></div>
        <div className="panel-body">
          <div style={{ fontSize:'var(--t-md)', marginBottom:12 }}>Bolha recorrente em <span className="mono">H-——03</span> · Pintura · cabine 2</div>
          <div className="text-xxs muted mono uppercase" style={{ marginBottom:8 }}>4 CAUSAS PROVÁVEIS</div>
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {[
              { p:0.42, cause:'Humidade ambiente acima de —— %', evidence:'sensor cabine-2 às —:—' },
              { p:0.31, cause:'Tinta lote ——— fora de spec',     evidence:'CQ recepção — / — falhou' },
              { p:0.18, cause:'Temperatura cura abaixo de — °C',  evidence:'OPC-UA cura, h —:—' },
              { p:0.09, cause:'Operador ainda em curva de aprendizagem', evidence:'OP-—— ciclos < —' },
            ].map((c,i)=>(
              <div key={i} style={{ display:'grid', gridTemplateColumns:'48px 1fr 200px', gap:12, padding:12, background:'var(--bg-2)', border:'1px solid var(--bd-1)', borderRadius:4 }}>
                <div className="mono" style={{ fontSize:'var(--t-lg)', fontWeight:600, color: i===0?'var(--accent)':'var(--fg-1)' }}>{Math.round(c.p*100)}%</div>
                <div>
                  <div style={{ fontSize:'var(--t-sm)', fontWeight:500 }}>{c.cause}</div>
                  <div className="text-xs muted">evidência: {c.evidence}</div>
                </div>
                <div className="bar"><div className="bar-fill" style={{ width:`${c.p*100}%`, background:i===0?'var(--accent)':'var(--info)' }}/></div>
              </div>
            ))}
          </div>
          <div style={{ marginTop:14, padding:12, background:'var(--bg-2)', borderLeft:'3px solid var(--info)', borderRadius:4 }}>
            <div className="text-xxs muted mono uppercase" style={{marginBottom:6}}>ACÇÃO RECOMENDADA</div>
            <div className="text-sm">Calibrar sensor humidade da cabine 2 e bloquear lote ——— até CQ recepção. ETA — h.</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function QualOEETab() {
  return (
    <div className="kpi-grid" style={{ gridTemplateColumns:'repeat(3, 1fr)' }}>
      {[
        { l:'Disponibilidade', v:'—', u:'%', spark:[0.6,0.7,0.8,0.75,0.85,0.82,0.88], a:'var(--success)' },
        { l:'Performance',     v:'—', u:'%', spark:[0.5,0.55,0.6,0.65,0.6,0.7,0.72], a:'var(--info)' },
        { l:'Qualidade',       v:'—', u:'%', spark:[0.8,0.85,0.83,0.9,0.92,0.91,0.94], a:'var(--success)' },
      ].map((k,i)=>(
        <KPI2 key={i} label={k.l} value={k.v} unit={k.u} trend="—pp vs. baseline" trendDir="up" trust="A" spark={k.spark} accent={k.a}/>
      ))}
    </div>
  );
}

// ============================================================
// CONFIGURAÇÃO
// ============================================================
function ConfiguracaoPage() {
  const [tab, setTab] = useState2('scheduling');
  return (
    <div className="page" data-screen-label="07 Configuração">
      <div className="page-header">
        <div>
          <h1 className="page-title">Configuração</h1>
          <p className="page-subtitle">TENANT NELO · — UTILIZADORES · — REGRAS APRENDIDAS</p>
        </div>
        <div className="page-actions">
          <button className="btn"><Icons2.Download size={14}/>Exportar config</button>
          <button className="btn btn-primary"><Icons2.Lock size={14}/>Bloquear</button>
        </div>
      </div>
      <Tabs2 value={tab} onChange={setTab} tabs={[
        { id:'scheduling', label:'Scheduling' },
        { id:'cura',       label:'Cura · Secagem' },
        { id:'moldes',     label:'Moldes' },
        { id:'qualidade',  label:'Qualidade' },
        { id:'aprendiz',   label:'Aprendizagem', count: 28 },
        { id:'trust',      label:'Trust Index' },
        { id:'dados',      label:'Dados Mestre' },
        { id:'acessos',    label:'Acessos' },
        { id:'auditoria',  label:'Auditoria' },
        { id:'sistema',    label:'Sistema' },
      ]}/>
      {tab==='scheduling' && <SchedConfigTab/>}
      {tab==='aprendiz' && <AprendConfigTab/>}
      {tab==='trust' && <TrustConfigTab/>}
      {(tab==='cura'||tab==='moldes'||tab==='qualidade') && <GenericFormTab/>}
      {tab==='dados' && <DadosMestreTab/>}
      {tab==='acessos' && <AcessosTab/>}
      {tab==='auditoria' && <AuditoriaTab/>}
      {tab==='sistema' && <SistemaTab/>}
    </div>
  );
}

function SchedConfigTab() {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
      <div className="panel">
        <div className="panel-header"><div className="panel-title">Pesos da função objectivo</div></div>
        <div className="panel-body" style={{ display:'flex', flexDirection:'column', gap:14 }}>
          {['Cumprimento prazo','Custo por barco','Ocupação molde','Carga operador','Risco SPOF'].map((w,i)=>(
            <div key={w}>
              <div className="row gap-2" style={{ alignItems:'center', marginBottom:6 }}>
                <div style={{ flex:1, fontSize:'var(--t-sm)' }}>{w}</div>
                <span className="mono text-xs muted">{[0.40,0.25,0.15,0.10,0.10][i].toFixed(2)}</span>
              </div>
              <div style={{ position:'relative', height:6, background:'var(--bg-3)', borderRadius:3 }}>
                <div style={{ position:'absolute', left:0, top:0, height:'100%', width:`${[40,25,15,10,10][i]}%`, background:'var(--accent)', borderRadius:3 }}/>
                <div style={{ position:'absolute', left:`${[40,25,15,10,10][i]}%`, top:-4, width:14, height:14, background:'var(--fg-0)', borderRadius:'50%', transform:'translateX(-50%)' }}/>
              </div>
            </div>
          ))}
          <div className="text-xs muted">Soma actual: 1.00 · normalizado.</div>
        </div>
      </div>
      <div className="panel">
        <div className="panel-header"><div className="panel-title">Constraints rígidas</div></div>
        <div className="panel-body">
          {[
            { l:'Cura mínima 6h após Pintura', v:true },
            { l:'Máx. 3 barcos em CQ simultâneos', v:true },
            { l:'Operador par mín. 1× sénior', v:true },
            { l:'Molde requer manutenção a cada 100 ciclos', v:true },
            { l:'Sem sobreposição de turnos', v:true },
          ].map((c,i)=>(
            <div key={i} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 0', borderBottom:'1px solid var(--bd-1)' }}>
              <div style={{ width:32, height:18, background: c.v?'var(--success)':'var(--bg-3)', borderRadius:9, position:'relative' }}>
                <div style={{ position:'absolute', top:2, left: c.v?16:2, width:14, height:14, background:'#fff', borderRadius:'50%' }}/>
              </div>
              <div className="text-sm flex-1">{c.l}</div>
              <span className="mono text-xxs muted">RÍGIDA</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AprendConfigTab() {
  return (
    <div className="panel">
      <div className="panel-header"><div className="panel-title">Regras aprendidas · 28</div>
        <div className="row gap-2">
          <span className="badge badge-success">— activas</span>
          <span className="badge badge-warning">— em revisão</span>
        </div>
      </div>
      <div className="panel-body flush">
        <table className="tbl">
          <thead><tr><th>ID</th><th>Regra</th><th>Origem</th><th>Confiança</th><th>Aplicações</th><th>Estado</th><th/></tr></thead>
          <tbody>
            {Array.from({length:8}).map((_,i)=>(
              <tr key={i}>
                <td className="mono">RUL-{String(100+i).padStart(3,'0')}</td>
                <td className="text-sm">SE <span className="mono text-xs">fase=Pintura ∧ humidade&gt;—%</span> ENTÃO <span className="mono text-xs">adiar — h</span></td>
                <td className="mono text-xs muted">{['CPO','OPERADOR','HUMANO','CPO','HUMANO','CPO','OPERADOR','HUMANO'][i]}</td>
                <td><div className="bar" style={{width:80}}><div className="bar-fill" style={{ width:`${70+(i*7)%30}%`, background: i%4===0?'var(--warning)':'var(--success)' }}/></div></td>
                <td className="mono num">—</td>
                <td><span className={`badge ${i%4===0?'badge-warning':'badge-success'}`}>{i%4===0?'REVISÃO':'ACTIVA'}</span></td>
                <td><div className="row gap-2"><button className="btn btn-sm btn-ghost"><Icons2.Eye size={12}/></button><button className="btn btn-sm btn-ghost"><Icons2.X size={12}/></button></div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function TrustConfigTab() {
  return (
    <div className="panel">
      <div className="panel-header"><div className="panel-title">Trust index · fontes de dados</div></div>
      <div className="panel-body">
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:12 }}>
          {['SAP MES','OPC-UA L1','OPC-UA L2','RFID Manuais','Cliente Forecast','SAP HR'].map((s,i)=>{
            const grade = ['A','A','B','B','C','A'][i];
            const c = grade==='A'?'var(--success)':grade==='B'?'var(--warning)':'var(--danger)';
            return (
              <div key={s} style={{ padding:14, background:'var(--bg-2)', border:`1px solid var(--bd-1)`, borderLeft:`3px solid ${c}`, borderRadius:6 }}>
                <div className="row gap-2" style={{alignItems:'center', marginBottom:8}}>
                  <Icons2.Database size={14} style={{color:c}}/>
                  <div style={{fontWeight:600}}>{s}</div>
                  <span className="badge" style={{ marginLeft:'auto', color:c, borderColor:c, background:'transparent' }}>{grade}</span>
                </div>
                <div className="kv text-xs">
                  <span className="k">Cobertura</span><span className="mono">{['96','89','82','71','64','94'][i]}%</span>
                  <span className="k">Frescura</span><span className="mono">— min</span>
                  <span className="k">Schema</span><span>{['ok','ok','ok','drift','ok','ok'][i]}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function GenericFormTab() {
  return (
    <div className="panel">
      <div className="panel-body">
        <div className="kv" style={{ rowGap:14, fontSize:'var(--t-sm)' }}>
          {['Tempo mínimo de cura','Temperatura cura','Humidade máxima','Ciclos antes manutenção','Validação CQ obrigatória','Buffer entre fases'].map(l=>(
            <React.Fragment key={l}>
              <span className="k" style={{paddingTop:8}}>{l}</span>
              <div style={{ display:'flex', gap:8 }}>
                <input className="search" style={{ width:120, paddingLeft:10 }} placeholder="—"/>
                <select className="search" style={{ width:80, paddingLeft:10, appearance:'none' }}><option>h</option></select>
              </div>
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}

function DadosMestreTab() {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'200px 1fr', gap:16 }}>
      <div className="panel">
        <div className="panel-body" style={{ padding:8 }}>
          {['Produtos','Máquinas','Operações','BOM','Clientes','Fornecedores','Tarifas','Tenants'].map((s,i)=>(
            <div key={s} className={`nav-item ${i===0?'active':''}`} style={{margin:0}}>
              <Icons2.FileText size={12}/>
              {s}
              <span className="nav-count">—</span>
            </div>
          ))}
        </div>
      </div>
      <div className="panel">
        <div className="panel-header"><div className="panel-title">Produtos · catálogo</div><button className="btn btn-sm"><Icons2.Plus size={12}/>Adicionar</button></div>
        <div className="panel-body flush">
          <table className="tbl">
            <thead><tr><th>SKU</th><th>Nome</th><th>Categoria</th><th>Cliente</th><th>Activo</th></tr></thead>
            <tbody>
              {Array.from({length:6}).map((_,i)=>(
                <tr key={i}><td className="mono">PROD-{String(100+i).padStart(3,'0')}</td><td>—— ▮▮▮▮▮</td><td>—— —</td><td className="mono text-xs">CLI-——</td><td><span className="badge badge-success">SIM</span></td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function AcessosTab() {
  return (
    <div className="panel">
      <div className="panel-header"><div className="panel-title">Roles & permissões</div></div>
      <div className="panel-body flush">
        <table className="tbl">
          <thead><tr><th>Role</th><th>Painel</th><th>Produção</th><th>Planeamento</th><th>Expedição</th><th>Equipa</th><th>Configuração</th><th>Aprovar</th></tr></thead>
          <tbody>
            {[
              ['manager_operations',  [1,1,1,1,1,1,1]],
              ['planner_supply',      [1,1,1,1,0,0,1]],
              ['operator',            [0,0,0,0,0,0,0]],
              ['finance_controller',  [1,0,0,0,0,0,0]],
              ['admin_platform',      [1,1,1,1,1,1,1]],
            ].map(([r, p]) => (
              <tr key={r}><td className="mono">{r}</td>{p.map((v,i)=>(<td key={i}>{v?<Icons2.Check size={14} style={{color:'var(--success)'}}/>:<Icons2.X size={14} style={{color:'var(--fg-3)'}}/>}</td>))}</tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AuditoriaTab() {
  return (
    <div className="panel">
      <div className="panel-body flush">
        <table className="tbl">
          <thead><tr><th>Timestamp</th><th>Utilizador</th><th>Acção</th><th>Recurso</th><th>Justificação</th></tr></thead>
          <tbody>
            {Array.from({length:8}).map((_,i)=>(
              <tr key={i}>
                <td className="mono text-xs">—— —:—:—</td>
                <td className="mono">{['JF','MR','admin','JF','MR'][i%5]}</td>
                <td className="mono text-xs">{['APROVAR','MOVER','EDITAR','REJEITAR','EXPORTAR'][i%5]}</td>
                <td className="mono text-xs">{['SUG-2057','H-——03','RUL-103','SUG-2061','REL-——'][i%5]}</td>
                <td className="text-xs muted">"motivo livre ▮▮▮▮▮▮"</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function SistemaTab() {
  return (
    <div className="kpi-grid" style={{ gridTemplateColumns:'repeat(4, 1fr)' }}>
      {[
        { l:'Uptime · 30d',   v:'—', u:'%' },
        { l:'API p95',       v:'—', u:'ms' },
        { l:'Eventos / min', v:'—' },
        { l:'Filas pendentes', v:'—' },
      ].map((k,i)=>(<KPI2 key={i} label={k.l} value={k.v} unit={k.u} trend="estável" trendDir="flat" trust="A" spark={[0.5,0.5,0.5,0.5,0.5,0.5,0.5]}/>))}
    </div>
  );
}

// ============================================================
// RELATÓRIOS
// ============================================================
function RelatoriosPage() {
  const [tab, setTab] = useState2('kpis');
  return (
    <div className="page" data-screen-label="08 Relatórios">
      <div className="page-header">
        <div>
          <h1 className="page-title">Relatórios</h1>
          <p className="page-subtitle">— TEMPLATES · — RELATÓRIOS GUARDADOS</p>
        </div>
        <div className="page-actions">
          <button className="btn"><Icons2.Calendar size={14}/>Período</button>
          <button className="btn btn-primary"><Icons2.Download size={14}/>Exportar PDF</button>
        </div>
      </div>
      <Tabs2 value={tab} onChange={setTab} tabs={[
        { id:'kpis',     label:'KPIs' },
        { id:'custos',   label:'Custos' },
        { id:'pricing',  label:'Pricing' },
        { id:'cenarios', label:'Cenários' },
        { id:'export',   label:'Templates' },
      ]}/>
      {tab==='kpis' && <KpisTab/>}
      {tab==='custos' && <CustosTab/>}
      {tab==='pricing' && <PricingTab/>}
      {tab==='cenarios' && <CenariosTab/>}
      {tab==='export' && <TemplatesTab/>}
    </div>
  );
}

function KpisTab() {
  return (
    <>
      <div className="kpi-grid">
        {[
          { l:'Receita · mês',     v:'—', u:'€', a:'var(--success)' },
          { l:'Margem operacional', v:'—', u:'%', a:'var(--info)' },
          { l:'Barcos entregues',   v:'—' },
          { l:'NPS · cliente',      v:'—' },
        ].map((k,i)=>(<KPI2 key={i} label={k.l} value={k.v} unit={k.u} trend="—%" trendDir="up" trust="A" spark={[0.3,0.4,0.45,0.5,0.6,0.65,0.7]} accent={k.a}/>))}
      </div>
      <div className="panel">
        <div className="panel-header"><div className="panel-title">Tendência · 12 meses</div></div>
        <div className="panel-body">
          <svg width="100%" height="240" viewBox="0 0 800 240">
            {[40,80,120,160,200].map(y => <line key={y} x1="0" y1={y} x2="800" y2={y} stroke="var(--bd-1)" />)}
            <polyline points="0,180 60,170 120,160 180,150 240,120 300,130 360,100 420,110 480,80 540,90 600,60 660,70 720,40 800,50" fill="none" stroke="var(--success)" strokeWidth="2"/>
            <polyline points="0,200 60,195 120,190 180,180 240,175 300,165 360,160 420,150 480,140 540,135 600,125 660,120 720,110 800,105" fill="none" stroke="var(--info)" strokeWidth="2" strokeDasharray="4 4"/>
            {Array.from({length:12}).map((_,i)=>(<text key={i} x={i*66+30} y="232" fontSize="9" fill="var(--fg-2)" textAnchor="middle" fontFamily="var(--font-mono)">M{i+1}</text>))}
          </svg>
          <div className="row gap-3" style={{justifyContent:'center', marginTop:8}}>
            <span className="row gap-2" style={{alignItems:'center'}}><span style={{width:16, height:2, background:'var(--success)'}}/><span className="text-xs muted">Receita</span></span>
            <span className="row gap-2" style={{alignItems:'center'}}><span style={{width:16, height:2, background:'var(--info)', borderTop:'1px dashed'}}/><span className="text-xs muted">Custo</span></span>
          </div>
        </div>
      </div>
    </>
  );
}

function CustosTab() {
  return (
    <div className="panel">
      <div className="panel-header"><div className="panel-title">Decomposição de custos · COGS</div></div>
      <div className="panel-body">
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:24 }}>
          <svg width="100%" height="280" viewBox="0 0 280 280">
            {[
              { v:35, c:'var(--info)' }, { v:25, c:'var(--success)' }, { v:18, c:'var(--accent)' }, { v:12, c:'var(--purple)' }, { v:10, c:'var(--warning)' }
            ].reduce((acc, s, i, arr) => {
              const start = arr.slice(0, i).reduce((a,b)=>a+b.v, 0);
              const a0 = (start / 100) * 2 * Math.PI - Math.PI / 2;
              const a1 = ((start + s.v) / 100) * 2 * Math.PI - Math.PI / 2;
              const x0 = 140 + 100*Math.cos(a0), y0 = 140 + 100*Math.sin(a0);
              const x1 = 140 + 100*Math.cos(a1), y1 = 140 + 100*Math.sin(a1);
              const large = s.v > 50 ? 1 : 0;
              acc.push(<path key={i} d={`M140,140 L${x0},${y0} A100,100 0 ${large} 1 ${x1},${y1} Z`} fill={s.c} stroke="var(--bg-1)" strokeWidth="2"/>);
              return acc;
            }, [])}
            <circle cx="140" cy="140" r="55" fill="var(--bg-1)"/>
            <text x="140" y="138" fontSize="10" fill="var(--fg-2)" textAnchor="middle" fontFamily="var(--font-mono)">TOTAL</text>
            <text x="140" y="156" fontSize="20" fill="var(--fg-0)" textAnchor="middle" fontWeight="600">— €</text>
          </svg>
          <div className="col gap-3">
            {[
              { l:'Materiais',  v:35, c:'var(--info)' },
              { l:'Mão-de-obra', v:25, c:'var(--success)' },
              { l:'Energia',    v:18, c:'var(--accent)' },
              { l:'Transporte', v:12, c:'var(--purple)' },
              { l:'Outros',     v:10, c:'var(--warning)' },
            ].map(s=>(
              <div key={s.l} className="row gap-3" style={{ alignItems:'center' }}>
                <span style={{ width:14, height:14, background:s.c, borderRadius:3 }}/>
                <span className="flex-1">{s.l}</span>
                <div className="bar" style={{ width:140 }}><div className="bar-fill" style={{ width:`${s.v}%`, background:s.c }}/></div>
                <span className="mono num text-sm" style={{ width:48, textAlign:'right' }}>{s.v}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function PricingTab() {
  return (
    <div className="panel">
      <div className="panel-body flush">
        <table className="tbl">
          <thead><tr><th>Produto</th><th>Cliente</th><th>Custo</th><th>Preço</th><th>Margem</th><th>Volume</th><th>Recomendação</th></tr></thead>
          <tbody>
            {Array.from({length:8}).map((_,i)=>(
              <tr key={i}>
                <td className="mono">PROD-{String(100+i).padStart(3,'0')}</td>
                <td className="mono text-xs">CLI-——</td>
                <td className="mono num">— €</td>
                <td className="mono num">— €</td>
                <td><span className={`badge ${i%4===0?'badge-warning':i%4===1?'badge-success':'badge-info'}`}>{['BAIXA','OK','OK','ALTA'][i%4]} —%</span></td>
                <td className="mono num">—</td>
                <td className="text-xs">{i%4===0?<><Icons2.TrendUp size={11} style={{color:'var(--success)'}}/> subir +— %</>:'manter'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CenariosTab() {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12 }}>
      {['Base','Optimista','Pessimista'].map((c,i)=>(
        <div key={c} className="panel" style={{ padding:0 }}>
          <div className="panel-header" style={{borderLeft:`3px solid ${['var(--info)','var(--success)','var(--danger)'][i]}`, paddingLeft:13}}>
            <div className="panel-title">{c}</div>
            <span className="badge badge-info">{['ACTUAL','+— %','−— %'][i]}</span>
          </div>
          <div className="panel-body">
            <div className="kv">
              <span className="k">Receita</span><span className="mono num">— €</span>
              <span className="k">Margem</span><span className="mono num">—%</span>
              <span className="k">Barcos</span><span className="mono num">—</span>
              <span className="k">Risco</span><span>{['MÉDIO','BAIXO','ALTO'][i]}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function TemplatesTab() {
  const tpls = [
    { n:'Produção · mensal',  d:'KPIs, defeitos, OEE, top barcos' },
    { n:'Por cliente',         d:'volumes, prazos, qualidade, satisfação' },
    { n:'Qualidade · semanal', d:'first-pass yield, defeitos, retrabalho' },
    { n:'Equipa · mensal',     d:'produtividade, alocação, fadiga' },
    { n:'Custos · trimestral', d:'COGS, decomposição, tendência' },
    { n:'Sustentabilidade',    d:'energia, emissões, desperdício' },
  ];
  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12 }}>
      {tpls.map((t,i)=>(
        <div key={t.n} className="panel" style={{ padding:16 }}>
          <div className="row gap-2" style={{alignItems:'center', marginBottom:10}}>
            <div style={{ width:32, height:32, borderRadius:6, background:'var(--bg-3)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--info)' }}>
              <Icons2.FileText size={16}/>
            </div>
            <div style={{ fontWeight:600, fontSize:'var(--t-md)' }}>{t.n}</div>
          </div>
          <div className="text-xs muted" style={{ marginBottom:12, lineHeight:1.5 }}>{t.d}</div>
          <div className="row gap-2">
            <button className="btn btn-sm flex-1"><Icons2.Eye size={11}/>Pré-ver</button>
            <button className="btn btn-sm btn-primary flex-1"><Icons2.Download size={11}/>Gerar</button>
          </div>
        </div>
      ))}
    </div>
  );
}

window.EquipaPage = EquipaPage;
window.QualidadePage = QualidadePage;
window.ConfiguracaoPage = ConfiguracaoPage;
window.RelatoriosPage = RelatoriosPage;
