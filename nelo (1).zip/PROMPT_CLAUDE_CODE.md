# PROMPT — REORGANIZAR FRONTEND PP1-NELO (de 48 para 8 páginas)

> **Para:** Claude Code, no repositório `frontend/` da Nelo.
> **Objectivo:** **Não construir features novas.** Reorganizar a sidebar e as rotas. 90% dos componentes já existem e são bons — o problema é que estão espalhados por 48 destinos quando deviam ser 8.
> **Esforço estimado:** ~30 horas. A maioria é mover ficheiros, adicionar tabs e reescrever a sidebar.

---

## §0 · LEITURA OBRIGATÓRIA ANTES DE COMEÇAR

Antes de tocar em nada, **lê e abre estes ficheiros em separadores** (não os modifiques, é só para ter contexto):

- `frontend/src/App.tsx` — rotas actuais
- `frontend/src/components/layout/Sidebar.tsx` — sidebar a substituir
- `frontend/src/pages/Dashboard.tsx`
- `frontend/src/pages/OpsInboxPage.tsx`
- `frontend/src/pages/plan/TimelinePage.tsx`
- `frontend/src/pages/plan/SchedulingPage.tsx`
- `frontend/src/pages/dispatch/DispatchPage.tsx`
- `frontend/src/pages/admin/SettingsPage.tsx`
- `frontend/src/pages/workforce/WorkforceDashboard.tsx`
- `frontend/src/pages/profit/QualityPage.tsx`
- `frontend/src/components/dark/ConsequenceBlock.tsx`
- `frontend/src/components/dark/SuggestionExplainer.tsx`
- `frontend/src/components/copilot/CopilotDrawer.tsx`

Confirma que existem antes de avançar. Se algum não existir, **PARA** e diz.

---

## §1 · PRINCÍPIOS NÃO NEGOCIÁVEIS

1. **NÃO apagar código.** Os ficheiros das 48 páginas continuam a existir. Só mudam as rotas que apontam para elas.
2. **NÃO reescrever componentes.** Os componentes (`dark/`, `palantir/`, `workforce/`, `copilot/`, `charts/`) ficam exactamente como estão.
3. **Páginas "fundidas"** viram tabs ou secções dentro de páginas-pai. O `<TimelinePage>` torna-se um `<TimelineSection>` chamado dentro do Painel.
4. **Redirects, não 404s.** Toda a rota antiga (`/plan/scheduling`, `/profit/oee`, etc.) faz redirect 301 para a nova.
5. **Copy 100% pt-PT.** Sem inglês a vazar (Settings → Configuração; Reports → Relatórios; Workforce → Equipa).
6. **Cada PR ≤ 1 página.** Não fazer um PR gigante. 10 PRs pequenos, um por linha da tabela §6.

---

## §2 · ESTADO FINAL — 8 PÁGINAS

Sidebar final, por esta ordem exacta:

| # | Ícone | Label pt-PT | Rota |
|---|---|---|---|
| 1 | `Home` | Painel | `/` |
| 2 | `Factory` | Produção | `/producao` |
| 3 | `CalendarRange` | Planeamento | `/planeamento` |
| 4 | `Truck` | Expedição | `/expedicao` |
| 5 | `Users` | Equipa | `/equipa` |
| 6 | `ShieldCheck` | Qualidade | `/qualidade` |
| 7 | `Settings` | Configuração | `/configuracao` |
| 8 | `BarChart3` | Relatórios | `/relatorios` |

**Sem sub-menus. Sem dropdowns. 8 destinos. Acabou.**

Acessos especiais (sem sidebar, só URL ou UmweltSwitcher):
- `/ceo` — `CEODashboardPage.tsx` (tal como está)
- `/operador` — `OperadorPage.tsx` (tal como está)

---

## §3 · MAPA DE COMPOSIÇÃO (página nova ← páginas existentes)

### 3.1 Painel (`/`)

```tsx
<PainelPage>
  <KPIStrip />                  {/* 4× LiveKPICard: €/dia, concluídos, em risco, alertas */}
  <AlertsSection />             {/* extraído de OpsInboxPage — alertas activos, top 5 */}
  <TimelineSection />           {/* extraído de TimelinePage — sugestões pendentes */}
  <LiveActivityFeed />          {/* já existe */}
  <CopilotDrawer />             {/* global, já existe */}
</PainelPage>
```

**Acção:**
- Manter `Dashboard.tsx` como base, renomear para `PainelPage.tsx` (ou wrapper).
- Extrair as secções principais de `OpsInboxPage.tsx` e `TimelinePage.tsx` para componentes (`AlertsSection.tsx`, `TimelineSection.tsx`) em `frontend/src/components/painel/`.
- `OpsInboxPage.tsx` e `TimelinePage.tsx` continuam a existir como ficheiros mas só são chamados via componentes extraídos.

---

### 3.2 Produção (`/producao`)

Página com **3 vistas alternáveis** num segmented control:

```
[ Por fase ▾ ]  [ Gantt ]  [ Tabela ]
```

```tsx
<ProducaoPage>
  <CapacityBar />              {/* extraído de CapacityPage — barra carga por centro */}
  <ViewToggle />               {/* segmented: phases | gantt | table */}
  {view === 'phases' && <PhaseColumnView />}      {/* CONSTRUIR — único componente novo */}
  {view === 'gantt'  && <GanttChart />}           {/* já existe */}
  {view === 'table'  && <DragDropPlanner />}      {/* já existe, 729L */}
</ProducaoPage>
```

**Acção:** ver §4 para o `PhaseColumnView`.

---

### 3.3 Planeamento (`/planeamento`)

```tsx
<PlaneamentoPage>
  <Tabs>
    <Tab id="atribuicao" label="Atribuição">
      <DragDropPlanner mode="assignment" />        {/* operadores↔barcos */}
    </Tab>
    <Tab id="materiais" label="Materiais">
      <MRPPageContent />                           {/* corpo de MRPPage */}
      <InventoryPageContent />                     {/* corpo de InventoryPage */}
    </Tab>
    <Tab id="forecast" label="Previsão">
      <ForecastPageContent />
    </Tab>
  </Tabs>
</PlaneamentoPage>
```

---

### 3.4 Expedição (`/expedicao`)

**Não tocar.** `DispatchPage.tsx` está bem como está. Só:
- Mover de `/plan/dispatch` para `/expedicao`.
- Renomear export para `ExpedicaoPage`.
- Adicionar redirect de `/plan/dispatch` → `/expedicao`.

---

### 3.5 Equipa (`/equipa`)

```tsx
<EquipaPage>
  <Tabs>
    <Tab id="lista" label="Lista">          <EmployeesPageContent /></Tab>
    <Tab id="alocacoes" label="Alocações"> <AllocationsPageContent /></Tab>
    <Tab id="produtividade" label="Produtividade"><ProductivityPageContent /></Tab>
    <Tab id="risco" label="Risco">         <WorkforceDashboard view="risk" /></Tab>
    <Tab id="simulador" label="Simulador"> <WorkforceDashboard view="simulator" /></Tab>
    <Tab id="formacao" label="Formação">   <WorkforceDashboard view="training" /></Tab>
  </Tabs>
</EquipaPage>
```

`PayrollPage` → mover para Configuração (tab "Salários").

---

### 3.6 Qualidade (`/qualidade`)

```tsx
<QualidadePage>
  <Tabs>
    <Tab id="resumo" label="Resumo">     <QualityPageOverview /></Tab>
    <Tab id="erros" label="Erros">       <QualityPageErrors /></Tab>
    <Tab id="moldes" label="Moldes">     <QualityPageMolds /></Tab>
    <Tab id="retrabalho" label="Retrabalho"><QualityPageRework /></Tab>
    <Tab id="diagnostico" label="Diagnóstico"><ExplainPageContent /></Tab>
    <Tab id="oee" label="OEE">           <OEEPageContent /></Tab>
  </Tabs>
</QualidadePage>
```

---

### 3.7 Configuração (`/configuracao`)

A `SettingsPage.tsx` já tem tabs (71KB). **Adicionar mais tabs:**

```
Tabs existentes (manter): Scheduling · Routing · Cura · Moldes · Workforce · Qualidade · Custos · Alertas · Transporte
Tabs novas:               Aprendizagem · Trust · Dados · Acessos · Auditoria · Sistema · Copilot · Dados Mestre
```

Mapeamento de tabs novas:
- **Aprendizagem** ← `LearnedRulesPage` + `RegrasPage`
- **Trust** ← `DQAPage`
- **Dados** ← `DataQualityPage` + `DataIngestionPage`
- **Acessos** ← `RBACPage`
- **Auditoria** ← `AuditTrailPage`
- **Sistema** ← `HealthDashboardPage` + `ToolRegistryPage`
- **Copilot** ← `RAGIngestPage`
- **Dados Mestre** (sub-tabs) ← `Products`, `Machines`, `Operations`, `BOM`, `Customers`, `Suppliers`, `Rates`, `Tenants`

---

### 3.8 Relatórios (`/relatorios`)

```tsx
<RelatoriosPage>
  <Tabs>
    <Tab id="kpis" label="KPIs">       <KPIsPageContent /></Tab>
    <Tab id="custos" label="Custos">   <COGSPageContent /></Tab>
    <Tab id="pricing" label="Pricing"> <PricingPageContent /></Tab>
    <Tab id="cenarios" label="Cenários"><ScenariosPageContent /></Tab>
    <Tab id="export" label="Exportar">
      <ReportTemplates />              {/* novo: 5-6 templates PDF/Excel */}
    </Tab>
  </Tabs>
</RelatoriosPage>
```

---

## §4 · O ÚNICO COMPONENTE NOVO — `PhaseColumnView`

Localização: `frontend/src/components/scheduling/PhaseColumnView.tsx` (~200L).

**Spec:**

```tsx
interface PhaseColumnViewProps {
  phases: Phase[];           // ex: ['Prep.Molde', 'Pintura', 'Laminagem', 'Cura', 'CQ', 'Embalagem']
  boats: Boat[];             // todos os barcos activos
  onMove: (boatId: string, fromPhase: string, toPhase: string) => Promise<void>;
}

interface Phase {
  id: string;
  name: string;
  capacity: number;          // máx barcos em paralelo
  cureHours?: number;        // se há cura/secagem
}

interface Boat {
  id: string;
  hull: string;
  client: { code: string; flag: string };
  phase: string;
  status: 'on_time' | 'at_risk' | 'late' | 'curing';
  workers: WorkerRef[];
  shipDate: string;
  daysToShip: number;
}
```

**Comportamento:**
- Layout em colunas horizontais; scroll-x se não couberem.
- Cada coluna: header (nome fase + carga `3/4` + barra mini) + lista de `BoatCard` compactos.
- **Drag-and-drop** com `@dnd-kit/core` (já no package.json). Ao soltar um barco numa coluna nova:
  1. Pré-visualização optimista.
  2. Mostrar `<ConsequenceBlock>` modal: "Mover #4275 de Lixagem para Pintura adianta 1d, mas atrasa #4280 em 2h."
  3. [Confirmar] / [Cancelar].
  4. Em confirmar → `onMove()`. Em falha → reverter.
- Cores **com ícone + label** (nunca cor sozinha): `on_time`✓ verde, `at_risk`⚠ amarelo, `late`✕ vermelho, `curing`⏱ cinza.
- Coluna em **sobrecarga** (>100% capacidade) mostra header com listra + ícone aviso.
- **Empty state** por coluna: "Sem barcos nesta fase" + ilustração leve.

**Reutilização:** importar `<BoatCard compact>` e `<ConsequenceBlock>` que já existem. **NÃO** criar novos.

---

## §5 · NOVA SIDEBAR

Substituir `frontend/src/components/layout/Sidebar.tsx` por uma versão de ~80 linhas:

```tsx
import { NavLink } from 'react-router-dom';
import { Home, Factory, CalendarRange, Truck, Users, ShieldCheck, Settings, BarChart3 } from 'lucide-react';

const NAV = [
  { to: '/',             label: 'Painel',       icon: Home },
  { to: '/producao',     label: 'Produção',     icon: Factory },
  { to: '/planeamento',  label: 'Planeamento',  icon: CalendarRange },
  { to: '/expedicao',    label: 'Expedição',    icon: Truck },
  { to: '/equipa',       label: 'Equipa',       icon: Users },
  { to: '/qualidade',    label: 'Qualidade',    icon: ShieldCheck },
  { to: '/configuracao', label: 'Configuração', icon: Settings },
  { to: '/relatorios',   label: 'Relatórios',   icon: BarChart3 },
];

export function Sidebar() {
  return (
    <aside className="w-60 border-r border-bd-1 bg-bg-1 flex flex-col">
      <Logo />
      <nav className="flex-1 p-3 flex flex-col gap-1">
        {NAV.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors
               ${isActive ? 'bg-bg-3 text-fg-0 font-medium' : 'text-fg-1 hover:bg-bg-2'}`
            }
          >
            <Icon size={16} className="text-fg-2" />
            {label}
            <NotificationDot to={to} />     {/* badge se houver alertas/sugestões */}
          </NavLink>
        ))}
      </nav>
      <UserBlock />
      <UmweltSwitcher />                   {/* já existe, manter */}
    </aside>
  );
}
```

**Sem grupos. Sem dropdowns. Sem expand/collapse.** Se um destino tem novidades, mostra um ponto laranja à direita do label.

---

## §6 · TAREFAS POR ORDEM DE PR

**Faz exactamente nesta ordem.** Cada linha = 1 PR. Não saltar passos.

| # | PR | Estimativa | Critério de pronto |
|---|---|---|---|
| 1 | **Sidebar nova** (8 ícones, sem sub-menus) | 2h | Sidebar antiga apagada; 8 links activos; UmweltSwitcher mantido. |
| 2 | **Rotas + redirects no `App.tsx`** | 3h | 8 rotas novas + redirects de TODAS as rotas antigas. Nada dá 404. |
| 3 | **Painel** = Dashboard + secções extraídas de Inbox + Timeline | 4h | Página única; 4 KPIs + alertas + timeline + activity feed; sem rotas separadas. |
| 4 | **Equipa** = Employees + Workforce + HR (tabs) | 3h | 6 tabs; cada tab carrega o conteúdo da página antiga; URL `/equipa?tab=risco` funciona. |
| 5 | **Configuração** = Settings + 11 admin pages (tabs) | 4h | SettingsPage estendida com 8 tabs novas; Dados Mestre como sub-tabs. |
| 6 | **Qualidade** = Quality + OEE + Explain (tabs) | 3h | 6 tabs; ExplainPage vira tab "Diagnóstico". |
| 7 | **Planeamento** = Scheduling assignment + MRP + Inventory + Forecast (tabs) | 2h | 3 tabs principais. |
| 8 | **`PhaseColumnView`** + integração na Produção | 6h | Componente novo testado; segmented control com 3 vistas; drag-drop funcional com ConsequenceBlock. |
| 9 | **Relatórios** = KPIs + COGS + Pricing + Scenarios + Export (tabs) | 2h | 5 tabs; templates de export PDF/Excel stub. |
| 10 | **Expedição** — só renomear rota | 30min | `/expedicao` funciona, `/plan/dispatch` redirige. |

**Total ≈ 30h.** Fazer uma de cada vez. Cada PR tem testes.

---

## §7 · REDIRECTS OBRIGATÓRIOS NO `App.tsx`

Adicionar **antes** de qualquer rota nova, todos os redirects das rotas antigas:

```tsx
{/* Redirects das rotas antigas → 8 páginas novas */}
<Route path="/inbox"            element={<Navigate to="/" replace />} />
<Route path="/decisions"        element={<Navigate to="/" replace />} />
<Route path="/suggestions"      element={<Navigate to="/" replace />} />

<Route path="/plan/scheduling"  element={<Navigate to="/producao" replace />} />
<Route path="/plan/timeline"    element={<Navigate to="/" replace />} />
<Route path="/plan/capacity"    element={<Navigate to="/producao" replace />} />
<Route path="/plan/mrp"         element={<Navigate to="/planeamento?tab=materiais" replace />} />
<Route path="/plan/dispatch"    element={<Navigate to="/expedicao" replace />} />

<Route path="/profit/oee"       element={<Navigate to="/qualidade?tab=oee" replace />} />
<Route path="/profit/quality"   element={<Navigate to="/qualidade" replace />} />
<Route path="/profit/cogs"      element={<Navigate to="/relatorios?tab=custos" replace />} />
<Route path="/profit/pricing"   element={<Navigate to="/relatorios?tab=pricing" replace />} />
<Route path="/profit/scenarios" element={<Navigate to="/relatorios?tab=cenarios" replace />} />
<Route path="/profit/kpis"      element={<Navigate to="/relatorios" replace />} />

<Route path="/hr/allocations"   element={<Navigate to="/equipa?tab=alocacoes" replace />} />
<Route path="/hr/payroll"       element={<Navigate to="/configuracao?tab=salarios" replace />} />
<Route path="/hr/productivity"  element={<Navigate to="/equipa?tab=produtividade" replace />} />

<Route path="/supply/inventory" element={<Navigate to="/planeamento?tab=materiais" replace />} />
<Route path="/supply/forecast"  element={<Navigate to="/planeamento?tab=forecast" replace />} />
<Route path="/supply/rop"       element={<Navigate to="/planeamento?tab=materiais" replace />} />
<Route path="/supply/abc"       element={<Navigate to="/relatorios" replace />} />

<Route path="/workforce"        element={<Navigate to="/equipa?tab=risco" replace />} />
<Route path="/workforce/*"      element={<Navigate to="/equipa?tab=risco" replace />} />

<Route path="/explain"          element={<Navigate to="/qualidade?tab=diagnostico" replace />} />
<Route path="/explain/:id"      element={<Navigate to="/qualidade?tab=diagnostico" replace />} />
<Route path="/twin"             element={<Navigate to="/qualidade?tab=diagnostico" replace />} />
<Route path="/sandbox"          element={<Navigate to="/planeamento?tab=simulador" replace />} />

<Route path="/core/*"           element={<Navigate to="/configuracao?tab=mestre" replace />} />
<Route path="/admin/*"          element={<Navigate to="/configuracao" replace />} />
<Route path="/settings"         element={<Navigate to="/configuracao" replace />} />
```

---

## §8 · RBAC — VISIBILIDADE POR ROLE

Adicionar à `Sidebar.tsx`:

```tsx
const NAV_BY_ROLE: Record<string, string[]> = {
  manager_operations:  ['/', '/producao', '/planeamento', '/expedicao', '/equipa', '/qualidade', '/configuracao', '/relatorios'],
  admin_platform:      ['/', '/producao', '/planeamento', '/expedicao', '/equipa', '/qualidade', '/configuracao', '/relatorios'],
  planner_supply:      ['/', '/producao', '/planeamento', '/expedicao'],
  finance_controller:  [],   // só /ceo via UmweltSwitcher
  operator:            [],   // só /operador, sem sidebar
};
```

`finance_controller` e `operator` **não vêem sidebar** — vão directo a `/ceo` ou `/operador`.

---

## §9 · TESTES

### 9.1 Unitários (Vitest)

- `Sidebar.test.tsx` — 8 links visíveis para `manager_operations`; 0 para `operator`.
- `PhaseColumnView.test.tsx` — render N colunas; drag entre colunas chama `onMove`.

### 9.2 Componente (Vitest + React Testing Library)

Para cada uma das 8 páginas-pai:
- Renderiza com sucesso.
- Mostra todas as tabs definidas.
- `?tab=X` na URL selecciona a tab `X`.

### 9.3 E2E (Playwright)

```ts
test('redirects de rotas antigas funcionam', async ({ page }) => {
  await page.goto('/plan/dispatch');
  await expect(page).toHaveURL('/expedicao');

  await page.goto('/profit/oee');
  await expect(page).toHaveURL('/qualidade?tab=oee');

  await page.goto('/workforce/risk');
  await expect(page).toHaveURL('/equipa?tab=risco');
});

test('Painel mostra alertas, timeline e KPIs sem navegar', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByTestId('kpi-strip')).toBeVisible();
  await expect(page.getByTestId('alerts-section')).toBeVisible();
  await expect(page.getByTestId('timeline-section')).toBeVisible();
});

test('PhaseColumnView drag-drop pede confirmação', async ({ page }) => {
  await page.goto('/producao');
  await page.getByRole('button', { name: 'Por fase' }).click();
  // simular drag de barco
  await page.dragAndDrop('[data-boat-id="4275"]', '[data-phase-id="pintura"]');
  await expect(page.getByText('Mover #4275')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Confirmar' })).toBeVisible();
});
```

---

## §10 · CHECKLIST DE PR (cada um deles)

Antes de pedir review, confirma:

- [ ] Apenas 1 página por PR (vê tabela §6).
- [ ] Nenhum componente em `dark/`, `palantir/`, `workforce/`, `copilot/`, `charts/` foi modificado.
- [ ] Nenhum ficheiro de página antiga foi apagado (continuam onde estão).
- [ ] Todas as rotas antigas que tocam neste PR têm `<Navigate>` correspondente.
- [ ] Copy 100% pt-PT. Sem "Settings", "Reports", "Workforce" no DOM.
- [ ] Cada cor de status tem ícone + label associados.
- [ ] Toda a acção destrutiva (mover, rejeitar, eliminar) passa por `<ConsequenceBlock>` antes de confirmar.
- [ ] Testes passam (`npm run test` + `npm run test:e2e`).
- [ ] Lighthouse: bundle inicial não cresce mais de 5% face a `main`.
- [ ] Screenshots before/after no PR para cada página tocada.

---

## §11 · O QUE NÃO TOCAR

Estes ficheiros estão bem. **Não modificar:**

- `pages/dispatch/DispatchPage.tsx` — só mudar a rota.
- `pages/OperadorPage.tsx`
- `pages/CEODashboardPage.tsx`
- `components/copilot/CopilotDrawer.tsx`
- `components/copilot/CopilotFab.tsx`
- `components/scheduling/DragDropPlanner.tsx`
- `components/dark/SuggestionExplainer.tsx`
- `components/dark/ConsequenceBlock.tsx`
- `components/dark/WorkerPairCard.tsx`
- `components/explain/ExplainDrawer.tsx`
- `components/dashboard/UmweltSwitcher.tsx`
- `components/palantir/LiveKPICard.tsx`
- Tudo em `components/charts/`
- Tudo em `components/workforce/`

Se precisares de adaptar **qualquer um** destes, **PARA** e justifica primeiro.

---

## §12 · COMO COMEÇAR

1. Cria branch `chore/sidebar-8-paginas`.
2. Faz PR #1 (Sidebar nova) — só esse, sem mais nada.
3. Espera aprovação.
4. Continua para PR #2 (Rotas + redirects), e por aí adiante na ordem da §6.

Não tentes fazer tudo num só PR. **Cada PR ≤ 1 página.**

Boa.
